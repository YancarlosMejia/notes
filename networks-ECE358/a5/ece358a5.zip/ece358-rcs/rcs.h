#pragma once

#include <netinet/in.h>

int rcsSocket();
int rcsBind(int index, struct sockaddr_in *addr);
int rcsGetSockName(int index, struct sockaddr_in *addr);
int rcsListen(int index);
int rcsAccept(int index, struct sockaddr_in *addr);
int rcsConnect(int index, const struct sockaddr_in *addr);
int rcsRecv(int index, void *buf, int len);
int rcsSend(int index, void *buf, int len);
int rcsClose(int index);
