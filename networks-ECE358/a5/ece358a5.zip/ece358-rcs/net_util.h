#pragma once

#include <netinet/in.h>

#define PORT_RANGE_LO 10000
#define PORT_RANGE_HI 11000

uint32_t getPublicIPAddr();
int mybind(int sockfd, struct sockaddr_in *addr);
