#pragma once

#include <netinet/in.h>

class RcsSocket {
  public:
    int sockfd;
    sockaddr_in *addr;
    int nextSend;
    int nextRecv;
    bool listening;

    RcsSocket(int sockfd);

    int send(void *buf, int len);
    int receive(void *buf, int len);
};
