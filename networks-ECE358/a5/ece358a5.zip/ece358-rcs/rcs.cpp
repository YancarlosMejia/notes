#include <errno.h>
#include <stdio.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>
#include <vector>

#include "rcs.h"
#include "rcs_socket.h"
#include "ucp.h"

#define TIMEOUT 500

std::vector<RcsSocket> sockets;

int rcsSocket() {
    int sockfd = ucpSocket();

    RcsSocket socket = RcsSocket(sockfd);
    sockets.push_back(socket);
    return sockets.size() - 1;
}

int rcsBind(int index, struct sockaddr_in *addr) {
    if (index < 0 || sockets.size() - 1 < (unsigned int)index) {
        printf("Could not bind to non-existent RcsSocket %d.\n", index);
        errno = ENXIO;
        return -1;
    }

    sockets[index].addr = addr;
    return ucpBind(sockets[index].sockfd, addr);
}

int rcsGetSockName(int index, struct sockaddr_in *addr) {
    if (index < 0 || sockets.size() - 1 < (unsigned int)index) {
        printf("Could not getsockname of non-existent RcsSocket %d.\n", index);
        errno = ENXIO;
        return -1;
    }

    return ucpGetSockName(sockets[index].sockfd, addr);
}

int rcsListen(int index) {
    if (index < 0 || sockets.size() - 1 < (unsigned int)index) {
        printf("Could not listen with non-existent RcsSocket %d.\n", index);
        errno = ENXIO;
        return -1;
    }

    sockets[index].listening = true;
    return 0;
}

int rcsAccept(int index, struct sockaddr_in *addr) {
    if (index < 0 || sockets.size() - 1 < (unsigned int)index) {
        printf("Could not accept with non-existent RcsSocket %d.\n", index);
        errno = ENXIO;
        return -1;
    }

    if (!sockets[index].listening) {
        printf("Could not accept on non-listening RcsSocket %d.\n", index);
        errno = ENOTCONN;
        return -1;
    }

    char buf[4];
    int syn = -1;
    int tries = 0, maxTries = 5;
    while (syn < 0 || strcmp((const char *)buf, "syn") != 0) {
        syn = ucpRecvFrom(sockets[index].sockfd, buf, 4, addr);

        if (++tries >= maxTries) {
            printf("Did not receive syn on RcsSocket %d.\n", index);
            if (syn >= 0) {
                printf("Received %s.\n", buf);
            }
            errno = ECONNREFUSED;
            return -1;
        }
    }

    int client_idx = rcsSocket();
    sockets[client_idx].addr = addr;
    ucpSetSockRecvTimeout(sockets[client_idx].sockfd, TIMEOUT);

    int synack = -1;
    tries = 0;
    while (synack < 0) {
        synack = ucpSendTo(sockets[client_idx].sockfd, "syn-ack", 8, addr);

        if (++tries >= maxTries) {
            printf("Failed to send synack on RcsSocket %d.\n", client_idx);
            errno = ECONNABORTED;
            return -1;
        }
    }

    return client_idx;
}

int rcsConnect(int index, const struct sockaddr_in *addr) {
    if (index < 0 || sockets.size() - 1 < (unsigned int)index) {
        printf("Could not connect with non-existent RcsSocket %d.\n", index);
        errno = ENXIO;
        return -1;
    }

    int syn = ucpSendTo(sockets[index].sockfd, "syn", 4, addr);
    if (syn < 0) {
        printf("Failed to send syn on RcsSocket %d.\n", index);
        errno = ECOMM;
        return -1;
    }

    char buf[8];
    int synack = -1;
    int tries = 0, maxTries = 5;
    while (synack < 0 || strcmp((const char *)buf, "syn-ack") != 0) {
        synack = ucpRecvFrom(sockets[index].sockfd, buf, 8,
                             (struct sockaddr_in *)addr);

        if (++tries >= maxTries) {
            printf("Did not receive synack on RcsSocket %d.\n", index);
            if (syn >= 0) {
                printf("Received %s.\n", buf);
            }
            errno = ECONNREFUSED;
            return -1;
        }
    }

    ucpSetSockRecvTimeout(sockets[index].sockfd, TIMEOUT);

    return synack;
}

int rcsRecv(int index, void *buf, int len) {
    if (index < 0 || sockets.size() - 1 < (unsigned int)index) {
        printf("Could not recv with non-existent RcsSocket %d.\n", index);
        errno = ENXIO;
        return -1;
    }

    return sockets[index].receive(buf, len);
}

int rcsSend(int index, void *buf, int len) {
    if (index < 0 || sockets.size() - 1 < (unsigned int)index) {
        printf("Could not send with non-existent RcsSocket %d.\n", index);
        errno = ENXIO;
        return -1;
    }

    return sockets[index].send(buf, len);
}

int rcsClose(int index) {
    if (index < 0 || sockets.size() - 1 < (unsigned int)index) {
        printf("Could not close non-existent RcsSocket %d.\n", index);
        errno = ENXIO;
        return -1;
    }

    int close = ucpClose(sockets[index].sockfd);
    sockets.erase(sockets.begin() + index);
    return close;
}
