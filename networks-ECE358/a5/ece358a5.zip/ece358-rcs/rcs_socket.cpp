#include <errno.h>
#include <sstream>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "rcs_socket.h"
#include "ucp.h"

RcsSocket::RcsSocket(int sockfd)
    : sockfd(sockfd), addr(NULL), nextSend(0), nextRecv(0), listening(false) {
}

int checksum(char *buf, unsigned int len) {
    int total = 0;
    for (unsigned int i = 0; i < len; ++i) {
        if (buf[i] == 10) {
            break;
        }

        total += buf[i];
    }

    return total;
}

int RcsSocket::send(void *buf, int len) {
    std::stringstream sendBuf;
    sendBuf << nextSend++ << ":";
    sendBuf << checksum((char *)buf, len) << ":";
    len += sendBuf.str().length();
    sendBuf << (char *)buf;

    int bytesSent = ucpSendTo(sockfd, sendBuf.str().c_str(), len, addr);
    if (bytesSent < 0) {
        errno = ECOMM;
        return -1;
    }

    for (;;) {
        char bufRecv[128];
        int bytesRecv = ucpRecvFrom(sockfd, bufRecv, 128, addr);
        if (bytesRecv == -1) {
            ucpSendTo(sockfd, sendBuf.str().c_str(), len, addr);
            continue;
        }
        bufRecv[bytesRecv] = 0;

        strtok(bufRecv, ":");
        strtok(NULL, ":");
        const char *ack = strtok(NULL, ":");
        if (ack == NULL || strcmp(ack, "ack") != 0) {
            ucpSendTo(sockfd, sendBuf.str().c_str(), len, addr);
            continue;
        }

        return bytesSent;
    }

    errno = ECOMM;
    return -1;
}

int RcsSocket::receive(void *buf, int len) {
    int triesOOO = 0, maxTriesOOO = 5;

    for (;;) {
        int bytesRecv = ucpRecvFrom(sockfd, buf, len, addr);
        if (bytesRecv < 0) {
            continue;
        }
        ((char *)buf)[bytesRecv] = 0;

        char *packetNoStr = strtok((char *)buf, ":");
        if (packetNoStr == NULL) {
            printf("Received corrupt packet (NULL payload)\n");
            continue;
        }
        int packetNo = atoi(packetNoStr);
        if (packetNo != nextRecv) {
            printf("Received out-of-order packet %d (expected %d)\n", packetNo,
                   nextRecv);
            if (triesOOO++ < maxTriesOOO) {
                continue;
            }

            nextRecv--;
            triesOOO = 0;
        }

        char *checkStr = strtok(NULL, ":");
        if (checkStr == NULL) {
            printf("Received corrupt packet (NULL payload): %d\n", packetNo);
            continue;
        }
        int check = atoi(checkStr);

        char *payload = strtok(NULL, ":");
        if (NULL == payload || check != checksum(payload, strlen(payload))) {
            printf("Received corrupt packet: %d %d %s\n", packetNo, check,
                   payload);
            continue;
        }

        strncpy((char *)buf, payload, len);

        std::stringstream sendBuf;
        sendBuf << nextRecv++ << ":0:ack";
        int bytesSent = -1;
        int tries = 0, maxTries = 5;
        while (bytesSent < 0) {
            bytesSent = ucpSendTo(sockfd, sendBuf.str().c_str(),
                                  sendBuf.str().length(), addr);
            if (++tries >= maxTries) {
                errno = ECOMM;
                return -1;
            }
        }

        return strlen((char *)buf);
    }

    errno = ENODATA;
    return -1;
}
