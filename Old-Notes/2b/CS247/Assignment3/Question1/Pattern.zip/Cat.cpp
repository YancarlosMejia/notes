#include "Cat.h"


void Cat::soundOff() {
    std::cout<< "Meow!" << std::endl;
}
