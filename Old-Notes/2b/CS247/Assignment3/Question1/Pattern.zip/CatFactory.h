#ifndef H_CATFACTORY
#define H_CATFACTORY

#include "Cat.h"

class CatFactory {
public:
    Cat* create();
};

#endif
