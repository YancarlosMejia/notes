#ifndef H_FOX
#define H_FOX


#include "Sound.h"

class Fox : public Sound {
public:
    void soundOff();
};


#endif
