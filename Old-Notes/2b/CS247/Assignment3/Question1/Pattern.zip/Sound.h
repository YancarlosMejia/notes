#ifndef H_SOUND
#define H_SOUND


#include <iostream>

class Sound  {
public:
    virtual void soundOff() = 0;
};

#endif
