#ifndef H_FOXFACTORY
#define H_FOXFACTORY

#include "Fox.h"

class FoxFactory {
public:
    Fox* create();
};

#endif
