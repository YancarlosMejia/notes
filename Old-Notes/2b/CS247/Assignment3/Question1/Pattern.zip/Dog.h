#ifndef H_DOG
#define H_DOG

#include "Sound.h"

class Dog : public Sound {
public:
    void soundOff();
};

#endif
