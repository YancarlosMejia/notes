#include "Dog.h"


void Dog::soundOff() {
    std::cout<< "Woof!" << std::endl;
}
