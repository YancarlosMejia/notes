#include "Fox.h"


void Fox::soundOff() {
    std::cout<< "RING-DING-DING-DING-DING-DINGERINGEDING!" << std::endl;
}
