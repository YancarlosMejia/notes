#ifndef H_CAT
#define H_CAT


#include "Sound.h"

class Cat : public Sound {
public:
    void soundOff();
};

#endif
