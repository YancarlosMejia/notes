#ifndef H_DOGFACTORY
#define H_DOGFACTORY


#include "Dog.h"

class DogFactory {
public:
    Dog* create();
};

#endif
