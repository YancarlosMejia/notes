#include "YumRestaurant.h"

// ---------------------------------------------------------------------------
YumRestaurant::YumRestaurant()
{
  // nothing
}

// ---------------------------------------------------------------------------

YumRestaurant::~YumRestaurant()
{
  // nothing
}
