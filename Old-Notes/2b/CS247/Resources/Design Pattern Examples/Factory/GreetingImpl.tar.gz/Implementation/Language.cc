/*
 *  Language.cc
 *  Assignment 3
 *
 *  Created by Adam Lesinski on 10-07-24.
 *  Copyright 2010 Student. All rights reserved.
 *
 */

#include "Language.h"

Language::Language()
{}

Language::~Language()
{}

LanguageFactory::LanguageFactory()
{}

LanguageFactory::~LanguageFactory()
{}