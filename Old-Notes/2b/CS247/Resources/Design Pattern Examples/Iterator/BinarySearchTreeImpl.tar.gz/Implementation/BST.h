#ifndef BSTNODE_H_
#define BSTNODE_H_

#include <deque>

class BSTNode;

//the iterator class, used to iterate linearly over a BST
class BSTIterator {
public:
	BSTIterator(BSTNode* tree);
	~BSTIterator() {}

	BSTIterator& operator++();
	BSTIterator operator++(int);  // postfix operator++
	int& operator*();

	BSTIterator next() const;
	bool hasNext() const;

private:
	std::deque<BSTNode*> node_stack_;
};

//recursive BST structure
class BSTNode {
public:
	BSTNode(int value) : left_(NULL), right_(NULL), value_(value) {}
	~BSTNode();

	void insert(int value);
	BSTIterator createFirstIterator();

private:
	friend class BSTIterator;
	BSTNode* left_;
	BSTNode* right_;
	int value_;
};


#endif