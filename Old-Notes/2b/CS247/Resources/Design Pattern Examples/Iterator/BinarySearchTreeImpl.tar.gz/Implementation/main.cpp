#include <iostream>

#include "BST.h"

using namespace std;

int main(int argc, char** argv) {

	BSTNode tree(30);

	tree.insert(5);
	tree.insert(60);
	tree.insert(20);
	tree.insert(54);
	tree.insert(0);

	BSTIterator itr = tree.createFirstIterator();

	//easy to traverse with iterator
	while(itr.hasNext()) {
		cout << *itr << endl;
		itr++;
	}

	return 0;
}