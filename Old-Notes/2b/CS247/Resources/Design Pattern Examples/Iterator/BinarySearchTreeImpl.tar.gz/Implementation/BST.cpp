#include "BST.h"

//initialize to smallest value
BSTIterator::BSTIterator(BSTNode* tree) {
	if(tree != NULL) {
		node_stack_.push_front(tree);
	
		while(node_stack_.front()->left_ != NULL) {
			node_stack_.push_front(node_stack_.front()->left_);
		}
	}
}


//traverse using a stack
BSTIterator& BSTIterator::operator++() {
	
	BSTNode* top = node_stack_.front();
	node_stack_.pop_front();

	if(top->right_ != NULL) {
		node_stack_.push_front(top->right_);

		while(node_stack_.front()->left_ != NULL) {
			node_stack_.push_front(node_stack_.front()->left_);
		}
	}

	return *this;
}

// postfix operator++
BSTIterator BSTIterator::operator++(int) {
	BSTIterator retItr(*this);

	++(*this);

	return retItr;
}

int& BSTIterator::operator*() {
	return node_stack_.front()->value_;
}

BSTIterator BSTIterator::next() const {
	BSTIterator retItr(*this);

	return ++retItr;
}

bool BSTIterator::hasNext() const {
	return node_stack_.size() != 0;
}

BSTNode::~BSTNode() {
	delete left_;
	delete right_;
}

//recursive insert
void BSTNode::insert(int value) {
	if (value < value_) {
		if (left_ != NULL) {
			left_->insert(value);
		} else {
			left_ = new BSTNode(value);
		}
	}
	else if (value > value_) {
		if (right_ != NULL) {
			right_->insert(value);
		} else {
			right_ = new BSTNode(value);
		}
	}
}

//get iterator to the smallest value
BSTIterator BSTNode::createFirstIterator() {
	return BSTIterator(this);
}