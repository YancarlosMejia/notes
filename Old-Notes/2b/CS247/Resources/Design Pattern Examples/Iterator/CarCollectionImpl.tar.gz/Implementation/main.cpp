//////////////////////////////////////////////////////////
// Filename: main.cpp
// Author:   CS 246 Staff, Antoine Bisson, Shaylan Govind
// Date:     10-07-24
//
// Description: Test Harness to demonstrate iterator design 
//              pattern
//
//////////////////////////////////////////////////////////


#include <iostream>
#include <string>
#include "collection.h"

using namespace std;

//************************************************************************
//  Helper variables and functions for test harness
//************************************************************************

//  test harness commands
enum Op {NONE, Add, Iterate,Sold};

// parse input command
Op convertOp(string opStr) {
	switch (opStr[0]) {
		case 'a': return Add;
		case 'i': return Iterate;		
		default: return NONE;
	}
}

int main()
{	
	cout << "Test harness for the Car Collection" << endl << endl;

	//Stores a collection of car objects
	Collection * newCollection = 
		new Collection("Govind Bisson Exotic Car Collection");
	
	//Adds some default car objects to the collection
	newCollection->setBaseCollection();
	
	
	// get input command
	cout << "Command (a:Add a new car, i:iterate over the collection):\n";
	string command;
	cin >> command;
	
	Op op = convertOp(command);
	
	while ( !cin.eof() ) {

		switch (op) {							
			case Add: {	//Get the user input for the car object data members
				string brand, model,year,miles,price,color;
				cout << "\nAdding a new car to the collection!\n";
				cout << "Brand (AUDI,BMW,FERRARI,GUMPERT,PORSCHE,SPYKER,TVR,VW): ";
				cin >> brand;
				cout << "Model (No spaces): ";
				cin >> model;
				cout << "Year: ";
				cin >> year;
				cout << "Mileage: ";
				cin >> miles;
				cout << "Price (no spaces) $: ";
				cin >> price;
				cout << "Color (BLACK,BLUE,GRAY,PURPLE,RED,SILVER,WHITE,YELLOW): ";
				cin >> color;
				newCollection->addElement
					(Car(brand,model,year,miles,price,color));				
				break;
			}				
				
			case Iterate: {	//Allows the user to iterate over the collection 
							//based on thier input
				cout << "\nIterating Mode!\n";
				
				string itType, itOption;//Stores the type of iteration that the
										//user wants to perform
				
				cout << "What sublist do you want to iterate over? (ALL,BRAND,MILEAGE,PRICE,YEAR): ";
				
				cin >> itType;
				
				if(itType == "ALL")//Check if the user wants a complete list
				{
					itOption = "none";
				}
				else if (itType == "BRAND")	//Check if they just want a list of 
											//cars from just one brand
				{	
					cout << "Which Brand of cars do you want to see(AUDI,BMW,FERRARI,GUMPERT,PORSCHE,SPYKER,TVR,VW):";
					cin>>itOption;	//Get which brand they want			

				}else if(itType == "MILEAGE")//Check if they just want a list of 
											//cars under a certain mileage
				{
					cout << "Enter a maximum desired mileage:";
					cin>>itOption;	//Get the minimum mileage value

				}else if(itType == "PRICE")//Check if they just want a list of 
											//cars under a certain price
				{
					cout << "Enter a maximum desired price:";
					cin>>itOption;	//Get the maximum price value

				}else if(itType == "YEAR")//Check if they just want a list of 
										  //cars built during or after a certain
										  //year
				{	
					cout << "Enter a minimum desired year:";
					cin>>itOption;	//Get the minimum year value
				}

				cout << endl;

				//Create a new iterator with the variables that indicate the type
				
				CollectionIterator* carIterator = 
					new CollectionIterator(newCollection,itType,itOption);
				
				newCollection->print(carIterator);	//Print out the desired list
													//using the iterator				
				break;
			}

			default: {
				cout << "Invalid command." << endl;
			}
		} // switch command
		
		//Get the next command
		cout << endl << "Command(a:Add a new car, i:iterate over the collection):";
		cin >> command;
		op = convertOp(command);
		
		
	} // while cin OK
	

}