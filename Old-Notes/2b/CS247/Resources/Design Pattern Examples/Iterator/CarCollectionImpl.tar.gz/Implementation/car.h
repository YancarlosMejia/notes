//////////////////////////////////////////////////////////
// Filename: car.h
// Author:   Antoine Bisson, Shaylan Govind
// Date:     10-07-24
//
// Description: Defintions of methods implemented in  
//              car.cpp
//
//////////////////////////////////////////////////////////

#ifndef _CAR_H_
#define _CAR_H_

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <list>
#include <string>
#include <iostream>
#include <vector>
#include <map>
#include <fstream>
#include <sstream>

using std::string;


class Car	//Car object that stores the information about a specific car
{
public:
	//Constructor
	Car(string b,string m,string y,string mile,string p,string c) : 
	  _brand(b), _model(m),_year(y),_mileage(mile),	_price(p),_color(c){}

	string getBrand() const;	//Accessors
	string getModel() const;
	string getYear() const;
	string getMileage() const;
	string getPrice() const;
	string getColor() const;	
	
private:
	  string _brand;  //Data members that store the information about the car
	  string _model;
	  string _year;
	  string _mileage;
	  string _price;
	  string _color;
};

//Streaming operator
std::ostream & operator<<( std::ostream & out, const Car & c );

#endif