//////////////////////////////////////////////////////////
// Filename: iterator.cpp
// Author:   CS 246 Staff, Antoine Bisson, Shaylan Govind
// Date:     10-07-24
//
// Description: Implementation of methods defined in  
//              iterator.h
//
//////////////////////////////////////////////////////////

#include "iterator.h"
#include "collection.h"

bool CollectionIterator::hasNext()	//Checks if there is an item left in the
									//collection that matches the type of item
									//specified by the iterator variables
{
	return (_cursor < _collect->size());
}


Car CollectionIterator::next()	//Returns the current item that the iterator 
								//points to and finds the next item in the	
								//collection that matches the type of item
								//specified by the iterator variables
{ 
	Car result = (_collect->getElem(_cursor)); //Set the return value
	
	_cursor += 1;//Check the next element

	//Checks the rest of the collection for the next item that matches the type 
	//of item specified by the iterator variables and sets the cursor value so
	//that the iterator points to it

	if(hasNext()){
		if(	_iteratorMethod=="ALL"){
			return result;
		}else if(_iteratorMethod=="BRAND"){
			while(hasNext()&&(_collect->getElem(_cursor).getBrand()!=_iteratorMethod_Value)){
				_cursor++;		
			}
		}else if(_iteratorMethod=="YEAR"){
			while(hasNext()&&(atoi(_collect->getElem(_cursor).getYear().c_str())<atoi(_iteratorMethod_Value.c_str()))){
				_cursor++;			
			}
		}else if(_iteratorMethod=="MILEAGE"){
			while(hasNext()&&(atoi(_collect->getElem(_cursor).getMileage().c_str())>atoi(_iteratorMethod_Value.c_str()))){
				_cursor++;				
			}
		}else if(_iteratorMethod=="PRICE"){
			while(hasNext()&&(atoi(_collect->getElem(_cursor).getPrice().c_str())>atoi(_iteratorMethod_Value.c_str()))){
				_cursor++;				
			}
		}
	}	
	
	return result;
}

void CollectionIterator::first()//Finds the first item in the collection that
								 //matches the type of item specified by the 
								 //iterator variables
{	
	_cursor = 0;	//Check the first element in the list
	
	//Find the first element in the collection that matches the criteria defined
	//in _iteratorMethod and _iteratorMethod_Value

	if(_iteratorMethod=="BRAND"){
		while((hasNext())&&(_collect->getElem(_cursor).getBrand()!=_iteratorMethod_Value)){
			_cursor++;			
		}
	}else if(_iteratorMethod=="YEAR"){
		while((hasNext())&&(atoi(_collect->getElem(_cursor).getYear().c_str())<atoi(_iteratorMethod_Value.c_str()))){
			_cursor++;			
		}
	}else if(_iteratorMethod=="MILEAGE"){
		while((hasNext())&&(atoi(_collect->getElem(_cursor).getMileage().c_str())>atoi(_iteratorMethod_Value.c_str()))){
			_cursor++;			
		}
	}else if(_iteratorMethod=="PRICE"){
		while((hasNext())&&(atoi(_collect->getElem(_cursor).getPrice().c_str())>atoi(_iteratorMethod_Value.c_str()))){
			_cursor++;			
		}
	}

}