//////////////////////////////////////////////////////////
// Filename: iterator.h
// Author:   Antoine Bisson, Shaylan Govind
// Date:     10-07-24
//
// Description: Defintions of methods implemented in  
//              iterator.cpp
//
//////////////////////////////////////////////////////////

#ifndef _ITERATOR_H_
#define _ITERATOR_H_

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <list>
#include <string>
#include <iostream>
#include <vector>
#include <map>
#include <fstream>
#include <sstream>

#include "car.h"


class Collection;	//Forward Declaration

class CollectionIterator //Iterator to iterate over a collection
{ 

public: 
	CollectionIterator(Collection * c,string iM,string imV)
		//Constructor 
		//Takes a collection and 2 variable that define the type
		//of objects in the collection to be iterated over
	{		
		_collect = c;		
		_iteratorMethod = iM;
		_iteratorMethod_Value = imV;	
		first();
	}
	virtual ~CollectionIterator(){}
	virtual void first();	//Stores the first item in the iteration
	virtual bool hasNext(); //Checks if there exists anoter item to iterate over
	virtual Car next();		//Returns the current item and finds the next

	std::string _iteratorMethod;	     //Stores the type of items to be returned
	std::string _iteratorMethod_Value;   //Stores the sub-type of items to be returned

private:
	Collection * _collect;	//Stores the collection to be iterated over
	int _cursor;			//Stores the current item in the iteration	 
}; 

#endif