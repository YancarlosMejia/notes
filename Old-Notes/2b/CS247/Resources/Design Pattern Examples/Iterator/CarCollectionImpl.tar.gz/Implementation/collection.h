//////////////////////////////////////////////////////////
// Filename: collection.h
// Author:   Antoine Bisson, Shaylan Govind
// Date:     10-07-24
//
// Description: Defintions of methods implemented in  
//              collection.cpp
//
//////////////////////////////////////////////////////////

#ifndef _COLLECTION_H_
#define _COLLECTION_H_

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <list>
#include <string>
#include <iostream>
#include <vector>
#include <map>
#include <fstream>
#include <sstream>
#include "car.h"
#include "iterator.h"


class Collection//Collection object that holds a list of objects
{
public:
	Collection(string);				//Constructor
	virtual ~Collection(){}			//Destructor (virtual)
	void addElement(Car);			//Mutator
	virtual Car getElem(int);		//Accessor		
	std::string name();				//Accessor
	int size();						//Accessor
	void setBaseCollection();		//Mutator
	void print(CollectionIterator *);//Accessor
	
	//Create iterator
	virtual CollectionIterator * createIterator(std::string, std::string);

private:
	std::string _name;				//Stores the name of the collection
	std::vector<Car> _collection;	//Stores the objects in the collection
};

#endif