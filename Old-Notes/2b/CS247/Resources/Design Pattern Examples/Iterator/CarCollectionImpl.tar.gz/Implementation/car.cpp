//////////////////////////////////////////////////////////
// Filename: car.cpp
// Author:   Antoine Bisson, Shaylan Govind
// Date:     10-07-24
//
// Description: Implementation of methods defined in  
//              car.h
//
//////////////////////////////////////////////////////////

#include <iostream>
#include <string>
#include "car.h"

using namespace std;


string Car::getBrand() const	//Returns the brand of the car
{
	return _brand;
}

string Car::getModel() const	//Returns the model of the car
{
	return _model;
}

string Car::getYear() const		//Returns the year of the car
{
	return _year;
}

string Car::getMileage() const	//Returns the mileage of the car
{
	return _mileage;
}

string Car::getPrice() const	//Returns the price of the car
{
	return _price;
}

string Car::getColor() const	//Returns the colour of the car
{
	return _color;
}

std::ostream & operator<<( std::ostream & out, const Car & c ) {	
	//streaming operator - returns a formated string that contains all the 
	//information about a given car object

	out <<	"Brand:\t\t "			<<c.getBrand()	<<
			"\nModel:\t\t "			<<c.getModel()	<<
			"\nMileage(km):\t "	<<c.getMileage()<<
			"\nYear:\t\t "			<<c.getYear()	<<
			"\nPrice:\t\t $"		<<c.getPrice()	<<
			"\nColour:\t\t "		<<c.getColor();		
	
	out<<"\nAvailable\n-------------------------------------\n";
	
	return out;
} 