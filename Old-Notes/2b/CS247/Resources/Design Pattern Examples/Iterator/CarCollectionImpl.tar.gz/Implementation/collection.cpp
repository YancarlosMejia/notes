//////////////////////////////////////////////////////////
// Filename: collection.cpp
// Author:   Antoine Bisson, Shaylan Govind
// Date:     10-07-24
//
// Description: Implementation of methods defined in  
//              collection.h
//
//////////////////////////////////////////////////////////

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <list>
#include <string>
#include <iostream>
#include <vector>
#include <map>
#include <fstream>
#include <sstream>

#include "collection.h"

using namespace std;

Collection::Collection(string n)	//Constructor
{
	_name = n;
}

CollectionIterator* Collection::createIterator(string iM,string imV)
	//Collection Iterator creator
{
	return new CollectionIterator(this,iM,imV);
}

Car Collection::getElem(int i)	//Returns a specific element from the collection
{
	return _collection[i];
}

int Collection::size()	//Returns the size of the collection
{
	return _collection.size();
}

void Collection::addElement(Car c)	//Adds a car object element to the collection
{
	return _collection.push_back(c);
}


void Collection::setBaseCollection()//Adds a default list of cars the collection
{
	_collection.push_back(Car("BMW","330i","2010","6500","44002","BLACK"));
	_collection.push_back(Car("BMW","M3","2005","52200","29500","YELLOW"));
	_collection.push_back(Car("BMW","M3 CSL","2001","11000","75650","SILVER"));
	_collection.push_back(Car("AUDI","RS6 AVANT","2011","0","135000","BLUE"));
	_collection.push_back(Car("AUDI","R8 V10","2011","100","145000","RED"));
	_collection.push_back(Car("FERRARI","FXX","2008","1254","2100000","BLACK"));
	_collection.push_back(Car("GUMPERT","Appolo","2009","7522","988000","SILVER"));
	_collection.push_back(Car("PORSCHE","GT2 RS","2011","125","685000","BLACK"));
	_collection.push_back(Car("PORSCHE","GT1","1992","25006","1500200","WHITE"));
	_collection.push_back(Car("SPYKER","AERO","2005","17652","85652","GRAY"));
	_collection.push_back(Car("TVR","Tuscan","1996","65212","45872","RED"));
	_collection.push_back(Car("VW","GTI","2010","32570","11253","WHITE"));
	_collection.push_back(Car("VW","TOUAREG 3 TDI","2011","254","55890","BLUE"));
}

void Collection::print(CollectionIterator * cIT){
	//Prints out a list of cars
	//The list contains only the cars that meet the criteria defined in the 
	//iterator data members, _iteratorMethod and _iteratorMethod_Value

	while(cIT->hasNext()){
		cout << cIT->next() << endl;
	}

	cout <<"End of list."<<endl;

}