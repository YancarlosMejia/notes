#ifndef GROUP_UNIT_H
#define GROUP_UNIT_H

#include <string>
#include <vector>

#include "Unit.h"
#include "Iterator.h"

/**
 * The GroupUnit class contains information
 * about a group of unit (internal node) in 
 * a unit hierarchy.
 */
class GroupUnit : public Unit {
 public:
  // Constructor/Destructor
  explicit GroupUnit( std::string );
  virtual ~GroupUnit();

  // Iterator Pattern
  Iterator *createIterator();

  // Accessors
  int size();
  Unit *unit( int );

  // Mutators
  void addUnit( Unit * );
 
  // The unit actions
  void attack( Unit * );
  void damage( int );

 private:
  // The child units
  std::vector<Unit *> units_;
};

#endif
