#ifndef INDIVIDUAL_ITERATOR_H
#define INDIVIDUAL_ITERATOR_H

#include "Iterator.h"
#include "Unit.h"
#include "IndividualUnit.h"

/**
 * The IndividualIterator class is used to 
 * iterate through an IndividualUnit.
 */
class IndividualIterator : public Iterator {
 public: 
  // Constructor/Destructor
  IndividualIterator( IndividualUnit *unit );
  virtual ~IndividualIterator();

  // Set to first
  virtual void first();

  // Check if there is a next
  virtual bool hasNext();

  // Get the next unit
  virtual Unit *next();

 private:
  // The iterator's cursor
  Unit *cursor_;
};

#endif
