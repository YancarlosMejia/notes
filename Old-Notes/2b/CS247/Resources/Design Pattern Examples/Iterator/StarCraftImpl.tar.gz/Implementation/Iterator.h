#ifndef ITERATOR_H
#define ITERATOR_H

#include "Unit.h"

class Unit;

/**
 * The Iterator class is used to iterate
 * through the IndividualUnit of a composite
 * aggregation of Unit.
 */
class Iterator {
 public: 
  // Constructor/Destructor
  Iterator( Unit * );
  virtual ~Iterator();

  // Set to first
  virtual void first() = 0;

  // Check if there is a next
  virtual bool hasNext() = 0;

  // Get the next unit
  virtual Unit *next() = 0;

 protected:
  // The original unit
  Unit *root_;
};

#endif
