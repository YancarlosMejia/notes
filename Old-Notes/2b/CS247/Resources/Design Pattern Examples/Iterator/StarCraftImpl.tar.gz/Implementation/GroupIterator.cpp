#include <vector>

#include "GroupIterator.h"

using std::vector;

/**
 * The GroupIterator constructor, setup
 * the iterator for future iterations.
 */
GroupIterator::GroupIterator( GroupUnit *unit ) :
  Iterator( unit ),
  cursor_( 0 )
{
  // Fill a vector of child iterators for
  // children iteration
  int size = root_->size();
  for ( int i = 0; i < size; i++ ) {
    unitIters_.push_back( root_->unit(i)->createIterator() );
  }
}

/**
 * The GroupIterator destructor.
 */
GroupIterator::~GroupIterator() {
  int size = unitIters_.size();
  for ( int i = 0; i < size; i++ ) {
    delete unitIters_[i];
  }
}

/**
 * Resets the iterator to the first element.
 */
void GroupIterator::first() {
  // Set the cursor to 0
  cursor_ = 0;
  
  // Reset all child iterators
  int size = unitIters_.size();
  for ( int i = 0; i < size; i++ ) {
    unitIters_[i]->first();
  }
}

/**
 * Checks if there is still units left
 * over which to iterate.
 */
bool GroupIterator::hasNext() {
  // Get a copy of the cursor
  int cursor = cursor_;

  // Advance the new cursor until a child 
  // iterator with a next item is found
  while ( cursor < (int)unitIters_.size() &&
	  !unitIters_[cursor]->hasNext() ) {
    cursor += 1;
  }

  // If one is found, return true
  if ( cursor < (int)unitIters_.size() ) {
    return true;
  }

  // Else return false
  return false;
}

/**
 * Returns a pointer to the next unit.
 */
Unit *GroupIterator::next() {
  // Advance the cursor until a child iterator
  // with a next item is found
  while ( cursor_ < (int)unitIters_.size() &&
	  !unitIters_[cursor_]->hasNext() ) {
    cursor_ += 1;
  }

  // If one is found, call next on it
  if ( cursor_ < (int)unitIters_.size() ) {
    return unitIters_[cursor_]->next();
  }

  // Else return NULL.
  return NULL;
}
