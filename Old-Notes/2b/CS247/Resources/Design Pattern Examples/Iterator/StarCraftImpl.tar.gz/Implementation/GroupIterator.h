#ifndef GROUP_ITERATOR_H
#define GROUP_ITERATOR_H

#include <vector>

#include "Iterator.h"
#include "Unit.h"
#include "GroupUnit.h"

/**
 * The GroupIterator class is used to 
 * iterate through an IndividualUnit.
 */
class GroupIterator : public Iterator {
 public: 
  // Constructor/Destructor
  GroupIterator( GroupUnit *unit );
  virtual ~GroupIterator();

  // Set to first
  virtual void first();

  // Check if there is a next
  virtual bool hasNext();

  // Get the next unit
  virtual Unit *next();

 private:
  // Lower units iterators
  std::vector<Iterator *> unitIters_;
  
  // Cursor to current iterated unit
  int cursor_;
};

#endif
