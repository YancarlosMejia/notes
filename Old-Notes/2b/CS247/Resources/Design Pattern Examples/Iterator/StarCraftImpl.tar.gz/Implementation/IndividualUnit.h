#ifndef INDIVIDUAL_UNIT_H
#define INDIVIDUAL_UNIT_H

#include <string>

#include "Unit.h"
#include "Iterator.h"

/**
 * The IndividualUnit class contains information
 * about a leaf unit in a unit hierarchy.
 */
class IndividualUnit : public Unit {
 public:
  // Constructor/Destructor
  IndividualUnit( std::string, int, int );
  virtual ~IndividualUnit();

  // Iterator Pattern
  Iterator *createIterator();

  // Accessors
  int health();
  int strength();

  // The unit actions
  void attack( Unit * );
  void damage( int );

 private:
  // The unit's health points
  int health_;

  // The unit's damage points
  int strength_;
};

#endif
