#include <string>

#include "Unit.h"

using std::string;

/**
 * The Unit constructor, set the unit
 * name and state (to ALIVE).
 */
Unit::Unit( std::string name ) :
  name_(name),
  state_(ALIVE)
{
}

/**
 * The Unit destructor, deletes all of
 * its associated units.
 */
Unit::~Unit() {
  for ( int i = 0; i < size(); i++ ) {
    delete unit(i);
  }
}

/**
 * Returns the name of the unit.
 */
string Unit::name() {
  return name_;
}

/**
 * Returns the health of the unit.
 */
int Unit::health() {
  return 0;
}

/**
 * Returns the strength of the unit.
 */
int Unit::strength() {
  return 0;
}

/**
 * Returns the state of the unit.
 */
State Unit::state() {
  return state_;
}

/**
 * Returns the size of the children
 * of the unit.
 */
int Unit::size() {
  return 0;
}

/**
 * Returns the children unit at index.
 */
Unit *Unit::unit( int index ) {
  return NULL;
}
