#ifndef ARMY_H
#define ARMY_H

#include "Unit.h"

/**
 * The possible races for an army.
 */
enum Race {
  PROTOSS,
  TERRAN,
  ZERG
};

/**
 * The army class contains the information
 * on a player's army, including its 
 * associated units.
 */
class Army {
 public:
  // Constructor/Destructor
  Army( Race );
  ~Army();

  // Accessors
  Race race();
  Unit *unit();

  // Mutators
  void setUnit( Unit * );
  
 private:
  // The army race
  Race race_;
  
  // The root unit
  Unit *unit_;
};

#endif
