#ifndef UNIT_H
#define UNIT_H

#include <string>

#include "Iterator.h"

class Iterator;

/**
 * The Unit state.
 */
enum State {
  ALIVE,
  DEAD
};

/**
 * The Unit class contains information
 * about a unit in an army and allows
 * interactions between units.
 */
class Unit {
 public:
  // Constructor/Destructor
  Unit( std::string );
  virtual ~Unit();

  // Iterator Pattern
  virtual Iterator *createIterator() = 0;

  // Accessors
  std::string name();
  State state();

  // Virtual accessors
  virtual int health();
  virtual int strength();
  virtual int size();
  virtual Unit *unit(int);
 
  // The unit actions
  virtual void attack(Unit *) = 0;
  virtual void damage(int) = 0;

 protected:
  // The unit's name
  std::string name_;

  // The unit's state
  State state_;
};

#endif
