#include "Iterator.h"

/**
 * The Iterator constructor, set
 * the root unit of the iterator.
 */
Iterator::Iterator( Unit *unit ) :
  root_( unit )
{
}

/**
 * The Iterator destructor.
 */
Iterator::~Iterator() {
}
