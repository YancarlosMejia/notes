#include <string>

#include "IndividualUnit.h"
#include "IndividualIterator.h"

using std::string;

/**
 * The IndividualUnit constructor, set the
 * health and strenght of the unit.
 */
IndividualUnit::IndividualUnit( string name, int health, int strength ) :
  Unit(name),
  health_(health),
  strength_(strength)
{
}

/**
 * The IndividualUnit destructor.
 */
IndividualUnit::~IndividualUnit() {
}

/**
 * Returns an iterator pointing at the unit.
 */
Iterator *IndividualUnit::createIterator() {
  return new IndividualIterator( this );
}

/**
 * Returns the health of the unit.
 */
int IndividualUnit::health() {
  return health_;
}

/**
 * Returns the strength of the unit.
 */
int IndividualUnit::strength() {
  return strength_;
}

/**
 * Attacks another unit.
 */
void IndividualUnit::attack( Unit *target ) {
  target->damage( strength_ );
}

/**
 * Damages the unit.
 */
void IndividualUnit::damage( int damage ) {
  health_ -= damage;

  // If health goes below 0, set to dead
  if ( health_ < 0 ) {
    health_ = 0;
    state_ = DEAD;
  }
}
