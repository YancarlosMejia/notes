#include <iostream>
#include <sstream>

#include "Iterator.h"
#include "Army.h"
#include "Unit.h"
#include "IndividualUnit.h"
#include "GroupUnit.h"

using std::cout;
using std::endl;
using std::stringstream;

/**
 * Print the information about a given unit.
 */
void printInfo( Unit *unit ) {
  cout << unit->name() << endl;
  cout << "- Health   : " << unit->health() << endl;
  cout << "- Strength : " << unit->strength() << endl;
  cout << "- Status   : " << ( unit->state() == DEAD ? "DEAD" : "ALIVE" ) << endl;
  cout << endl;
}

/**
 * The main function.
 */
int main() {
  // Create an army
  Army army( ZERG );

  // Create a number of groups
  GroupUnit *swarm = new GroupUnit( "Swarm" );
  GroupUnit *pack1 = new GroupUnit( "Hydralisk Pack" );
  GroupUnit *pack2 = new GroupUnit( "Zergling Pack" );  
  GroupUnit *unit1 = new GroupUnit( "Zergling Swarm" );
  GroupUnit *unit2 = new GroupUnit( "Zergling Guard" );

  // Add a queen to the swarm
  swarm->addUnit( new IndividualUnit( "Queen", 120, 20 ) );

  // Add units to pack1
  for ( int i = 1; i <= 5; i++ ) {
    stringstream ss;
    ss << "Hydralisk " << i;
    pack1->addUnit( new IndividualUnit( ss.str(), 20, 5 ) );
  }

  // Add pack1 to the swarm
  swarm->addUnit( pack1 );

  // Add units to unit1
  for ( int i = 1; i <= 6; i++ ) {
    stringstream ss;
    ss << "Zergling " << i;
    unit1->addUnit( new IndividualUnit( ss.str(), 5, 2 ) );
  }

  // Add unit1 to pack2
  pack2->addUnit( unit1 );

  // Add units to unit2
  for ( int i = 7; i <= 12; i++ ) {
    stringstream ss;
    ss << "Zergling " << i;
    unit2->addUnit( new IndividualUnit( ss.str(), 5, 2 ) );
  }

  // Add unit2 to pack2
  pack2->addUnit( unit2 );

  // Add pack2 to the swarm
  swarm->addUnit( pack2 );

  // Set swarm at the root of the army
  army.setUnit( swarm );

  // Create an iterator
  Iterator *it = army.unit()->createIterator();

  // Iterate through the first 5, printing 
  // their name
  for ( int i = 0; i < 5; i++ ) {
    cout << it->next()->name() << endl << endl;
  }

  // Reset the iterator
  it->first();

  // Iterate through each individual units
  while ( it->hasNext() ) {
    printInfo( it->next() );   
  }

  delete it;

  return 0;
}
