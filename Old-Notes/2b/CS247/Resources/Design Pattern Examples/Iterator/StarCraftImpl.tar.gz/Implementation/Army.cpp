#include "Army.h"

/**
 * The Army constructor, creates an army
 * of the given race.
 */
Army::Army( Race race ) :
  race_(race),
  unit_(NULL)
{
}

/**
 * The Army destructor, deletes the unit
 * of the army.
 */
Army::~Army() {
  if ( unit_ != NULL ) {
    delete unit_;
  }
}

/**
 * Returns the race of the army.
 */
Race Army::race() {
  return race_;
}

/**
 * Returns the root unit of the army.
 */
Unit *Army::unit() {
  return unit_;
}

/**
 * Sets the root unit of the army,
 * deleting the current one.
 */
void Army::setUnit( Unit *unit ) {
  if ( unit_ != NULL ) {
    delete unit_;
  }
  unit_ = unit;
}
