#include <string>

#include "GroupUnit.h"
#include "GroupIterator.h"

using std::string;

/**
 * The GroupUnit constructor.
 */
GroupUnit::GroupUnit( string name ) :
  Unit( name )
{
}

/**
 * The GroupUnit destructor.
 */
GroupUnit::~GroupUnit() {
  for ( int i = 0; i < size(); i++ ) {
    delete unit(i);
  }
}

/**
 * Returns an iterator to this group.
 */
Iterator *GroupUnit::createIterator() {
  return new GroupIterator( this );
}

/**
 * Returns the size of the group (its
 * number of children).
 */
int GroupUnit::size() {
  return units_.size();
}

/**
 * Returns the unit at index or NULL
 * if there is none.
 */
Unit *GroupUnit::unit( int index ) {
  if ( index >= 0 && index < (int)units_.size() ) {
    return units_[index];
  }
  return NULL;
}

/**
 * Adds a unit to the group.
 */
void GroupUnit::addUnit( Unit *unit ) {
  units_.push_back( unit );
}

/**
 * Attacks a unit, calling attack on each
 * of the children of the group.
 */
void GroupUnit::attack( Unit *target ) {
  for ( int i = 0; i < size(); i++ ) {
    unit(i)->attack( target );
  }
}

/**
 * Damages the first non-dead child unit.
 */
void GroupUnit::damage( int damage ) {
  for ( int i = 0; i < size(); i++ ) {
    if ( units_[i]->state() != DEAD ) {
      units_[i]->damage( damage );
      return;
    }
  }
}
