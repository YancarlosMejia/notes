#include "IndividualIterator.h"

/**
 * The IndividualIterator constructor, sets 
 * a cursor to the unit.
 */
IndividualIterator::IndividualIterator( IndividualUnit *unit ) :
  Iterator( unit ),
  cursor_( unit )
{
}

/**
 * The IndividualIterator destructor.
 */
IndividualIterator::~IndividualIterator() {
}

/**
 * Resets the iterator to the root
 * unit.
 */
void IndividualIterator::first() {
  cursor_ = root_;
}

/**
 * Checks if the iterator has already iterated
 * over the root unit.
 */
bool IndividualIterator::hasNext() {
  if ( cursor_ == root_ ) {
    return true;
  }
  return false;
}

/**
 * Returns the value of cursor and sets it
 * to NULL.
 */
Unit *IndividualIterator::next() {
  Unit* tmp = cursor_;

  cursor_ = NULL;

  return tmp;
}
