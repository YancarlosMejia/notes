/*
 * BankAccount.cpp
 *
 *  Created on: 2010-07-29
 *      Author: Chang
 */

#include "BankAccount.h"

/*
 * Pre-condition: an amount is that greater or equal to 0
 * Post-condition: if amount <= account withdraw limit and
 * 				   amount <= current account balance, then
 * 				   money is withdrew and new account balance
 * 				   is updated
 */
void BankAccount :: withDraw(int amt) {
	if ( amt <= MaxLimit()  && amt <= amt_ ) {
		Approve( amt );
	} else {
	    Disapprove();
	}
}
