/*
 * RegularAccount.cpp
 *
 *  Created on: 2010-07-29
 *      Author: Chang
 */

#include "RegularAccount.h"
using namespace std;

/*
 * initialize static maxLimit data member
 */
int RegularAccount::maxLimit_ = 1000;

/*
 * pre-condition: amt is positive integer
 * post-condition: amt is added to current account balance
 */
void RegularAccount :: Deposit(int amt) {
	amt_ += amt;
}

/*
 * pre-condition: amt is positive integer
 * post-condition: amt is subtracted to current account balance
 */
void RegularAccount :: Approve(int amt) {
	amt_ -= amt;
	cout << "Your transaction has been approved!" << endl;
	cout << "Your account balance is " << amt_ << endl;
	cout << "Thank you for using regular account!" << endl;
}

void RegularAccount :: Disapprove() {
	cout << "Your transaction was not approved!" << endl;
	cout << "Your account balance is " << amt_ << endl;
	cout << "Your withdraw limit is 1000!" << endl;
}

/*
 * returns the maximum withdraw limit of VIP account
 */
int RegularAccount :: MaxLimit() {
	return maxLimit_;
}
