/*
 * VIPAccount.cpp
 *
 *  Created on: 2010-07-29
 *      Author: Chang
 */

#include "VIPAccount.h"
using namespace std;

/*
 * initialize static maxLimit data member
 */

int VIPAccount :: maxLimit_ = 2000;


/*
 * pre-condition: amt is positive integer
 * post-condition: amt is added to current account balance
 */
void VIPAccount :: Deposit(int amt) {
	amt_ += amt;
}

/*
 * pre-condition: amt is positive integer
 * post-condition: amt is subtracted to current account balance
 */
void VIPAccount :: Approve(int amt) {
	amt_ -= amt;
	cout << "Your transaction has been approved!" << endl;
	cout << "Your account balance is " << amt_ << endl;
	cout << "Thank you for using VIP account!" << endl;
}

void VIPAccount :: Disapprove() {
	cout << "Your transaction was not approved!" << endl;
	cout << "Your account balance is " << amt_ << endl;
	cout << "Your withdraw limit is 2000!" << endl;
}

/*
 * returns the maximum withdraw limit of VIP account
 */
int VIPAccount :: MaxLimit() {
	return maxLimit_;
}

