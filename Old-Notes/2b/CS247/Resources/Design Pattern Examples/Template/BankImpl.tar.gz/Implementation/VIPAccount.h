/*
 * VIPAccount.h
 *
 *  Created on: 2010-07-29
 *      Author: Chang
 */

#ifndef VIPACCOUNT_H_
#define VIPACCOUNT_H_

#include "BankAccount.h"
#include <iostream>

/*
 * Implements abstract base class BankAccount's
 * pure virtual functions to model specific
 * behaviour
 */
class VIPAccount : public BankAccount {
public:
	VIPAccount() {}
	void Deposit(int);
private:
	static int maxLimit_;
	void Approve(int);
	void Disapprove();
	int MaxLimit();	
};

#endif /* VIPACCOUNT_H_ */
