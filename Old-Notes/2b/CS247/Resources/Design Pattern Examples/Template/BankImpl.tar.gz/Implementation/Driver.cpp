/*
 * Driver.cpp
 *
 *  Created on: 2010-07-29
 *      Author: Chang
 */

#include "BankAccount.h"
#include "RegularAccount.h"
#include "VIPAccount.h"

#include <iostream>
#include <stdlib.h>
using namespace std;

/*
 * Main executable
 */
int main() {
	string input;
	RegularAccount *ra_;
	VIPAccount *va_;

	bool rflag = false;
	bool vflag = false;

	cout << "Please enter command 's' if you wish to open an account" << endl;

	while (getline(cin, input)) {
		if (input == "s") {
			cout << "Enter type of account" << endl;
			cout << "Enter 'r' if you wish to open a regular account" << endl;
			cout << "Enter 'v' if you wish to open a VIP account" << endl;
			while (1) {
				string type_;
				getline(cin, type_);
				cout << type_ << endl;

				if (type_ == "r") {
					ra_ = new RegularAccount();
					rflag = true;
					break;
				} else if (type_ == "v"){
					va_ = new VIPAccount();
					vflag = true;
					break;
				} else {
					cout << "Please re-enter command!" << endl;
				}
			}
			cout << "Thank you for creating an account!" << endl;
			cout << "Enter command 'd' if you wish to deposit" << endl;
			cout << "Enter 'x' if you wish to exit" << endl;
		} else if (input == "d") {
			cout << "Please specify the amount you wish to deposit" << endl;
			cout << "For example: 500" << endl;

			string amt_;
			getline(cin, amt_);

			char c[amt_.length()];
			for (int i=0; (unsigned)i<amt_.length(); i++)	 {
				c[i] = amt_[i];
			}

			if (rflag == true) {
				ra_->Deposit(atoi(c));
			} else if (vflag == true){
				va_->Deposit(atoi(c));
			}
			cout << "Thank you for depositing into your account" << endl;
			cout << "Enter command 'w' if you wish to withdraw" << endl;
			cout << "Enter 'x' if you wish to exit" << endl;
		} else if (input == "w") {
			cout << "Please specify the amount you wish to withdraw" << endl;
			cout << "For example: 500" << endl;

			string amt_;
			getline(cin, amt_);

			char c[amt_.length()];
			for (int i=0; (unsigned)i<amt_.length(); i++)	 {
				c[i] = amt_[i];
			}

			if (rflag == true) {
				ra_->withDraw(atoi(c));
			} else if (vflag == true) {
				va_->withDraw(atoi(c));
			}
			cout << "Would you like to make another transaction?" << endl;
			cout << "Enter 'y' for yes and 'n' for no"<< endl;

			string command_;
			getline(cin, command_);

			if (command_ == "n") {
				exit(1);
			}

			cout << "Enter command 'd' if you wish to deposit" << endl;
			cout << "Enter command 'w' if you wish to withdraw" << endl;
		} else if (input == "x") {
			exit(1);
		} else {
			cout << "Please re enter the commands!" << endl;
		}
	}

	delete ra_;
	delete va_;
}

