/*
 * BankAccount.h
 *
 *  Created on: 2010-07-29
 *      Author: Chang
 */

#ifndef BANKACCOUNT_H_
#define BANKACCOUNT_H_

/*
 * Implements template design pattern
 * all functions but withDraw(int) has
 * variable behaviour in subclasses
 * therefore withDraw(int) is the
 * template method and other functions are
 * declared as pure virtual
 */
class BankAccount {
public:
	virtual void Deposit(int) = 0;
	void withDraw(int);
protected:
	BankAccount () : amt_(0) {}
	int amt_;
private:
	virtual void Approve(int) = 0;
	virtual void Disapprove() = 0;
	virtual int MaxLimit() = 0;	
};

#endif /* BANKACCOUNT_H_ */
