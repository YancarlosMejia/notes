#ifndef TRADER_H_
#define TRADER_H_

#include <iostream>
#include <vector>

#include "FinancialMarket.h"

class FinancialMarket;

class Trader : public Observer 
{
public:
	virtual void buySecurity() = 0;
	virtual void sellSecurity() = 0;
	virtual void update() = 0;
	virtual int getNumSecurities() { return num_securities_; }
	void setMarket(FinancialMarket* market) { market_ = market; }
	
protected:
	FinancialMarket* market_;
	int num_securities_;
};

class IndividualTrader : public Trader
{
public:
	virtual void buySecurity();
	virtual void sellSecurity();
	virtual void update();
};

class FirmTrader : public Trader
{
public:
	virtual void buySecurity();
	virtual void sellSecurity();
	virtual void update();
};

class OrganizationTrader : public Trader
{
public:
	virtual void buySecurity();
	virtual void sellSecurity();
	virtual void update();
};

#endif
