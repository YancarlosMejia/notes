#include <iostream>

#include "FinancialMarket.h"

using namespace std;

void FinancialMarket::crash() {
	cout << "Crash, many people will be depressed..." << endl;
	notify();
}

void StockMarket::handleSell() {
	index_--;

	if(index_ <= 500) {
		has_crashed_ = true;
		cout << "Stock Market CRASHING" << endl;
		crash();
	}

	//any stock market specific stuff here

	notify();
}

void StockMarket::handleBuy() {
	index_++;

	//any stock market specific stuff here

	notify();
}

void BondMarket::handleSell() {
	index_--;

	if(index_ <= 500) {
		has_crashed_ = true;
		cout << "Bond Market CRASHED" << endl;
		crash();
	}

	//any bond market specific stuff here

	notify();
}

void BondMarket::handleBuy() {
	index_++;

	//any bond market specific stuff here

	notify();
}

void ForeignExchangeMarket::handleSell() {
	index_--;

	if(index_ <= 500) {
		has_crashed_ = true;
		cout << "Foreign Exchange Market CRASHED" << endl;
		crash();
	}

	//any foreign exchange market specific stuff here

	notify();
}

void ForeignExchangeMarket::handleBuy() {
	index_++;

	//any foreign exchange market specific stuff here

	notify();
}