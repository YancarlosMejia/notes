#include <iostream>

#include "Trader.h"
#include "FinancialMarket.h"

int main(int argc, char** argv) {

	FinancialMarket* tsx = new StockMarket();
	FinancialMarket* us_bond_market = new BondMarket();

	Trader* jeff = new IndividualTrader();
	Trader* sean = new IndividualTrader();
	Trader* warren_buffet = new IndividualTrader();
	Trader* TD = new FirmTrader();
	Trader* green_peace = new OrganizationTrader();

	tsx->subscribe(jeff);
	jeff->setMarket(tsx);

	tsx->subscribe(sean);
	sean->setMarket(tsx);

	tsx->subscribe(warren_buffet);
	warren_buffet->setMarket(tsx);

	us_bond_market->subscribe(TD);
	TD->setMarket(us_bond_market);

	us_bond_market->subscribe(green_peace);
	green_peace->setMarket(us_bond_market);

	//try and crash stock market by selling excessively
	//all subscribers should automatically be updated on the 
	//status of the stock market (resulting in happiness or depression)
	for(int i = 0; i < 250; ++i)
	{
		jeff->sellSecurity();
		sean->sellSecurity();
	}

	return 0;
}