#include "Trader.h"
#include <iostream>

using namespace std;

void IndividualTrader::buySecurity() {
	market_->handleBuy();
}

void IndividualTrader::sellSecurity() {
	market_->handleSell();
}

void IndividualTrader::update() {
	if(market_->hasCrashed())
		cout << "Individual is now depressed" << endl;
	else if (market_->getIndex() == 750)
		cout << "Individual is worried..." << endl;
	else if (market_->getIndex() >= 1500)
		cout << "Individual is happy!" << endl;

	//individual specific stuff here
}

void FirmTrader::buySecurity() {
	market_->handleBuy();
}

void FirmTrader::sellSecurity() {
	market_->handleSell();
}

void FirmTrader::update() {
	if(market_->hasCrashed())
		cout << "Firm is now bankrupt" << endl;

	if(market_->getIndex() >= 1500)
		cout << "Firm is doing good financially" << endl;

	//firm specific stuff here
}

void OrganizationTrader::buySecurity() {
	market_->handleBuy();
}

void OrganizationTrader::sellSecurity() {
	market_->handleSell();
}


void OrganizationTrader::update() {
	if(market_->hasCrashed())
		cout << "Organization is now bankrupt, can no longer offer support" << endl;

	if(market_->getIndex() >= 1500)
		cout << "Organization is doing great, many people in need will receive support" << endl;

	//organization specific stuff here
}