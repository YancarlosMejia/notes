#ifndef FINANCIAL_MARKET_H_
#define FINANCIAL_MARKET_H_

#include <string>

#include "Subject.h"
#include "Trader.h"


//abstract base class
class FinancialMarket : public Subject {
public:
	virtual ~FinancialMarket(){}
	virtual void handleSell() = 0;
	virtual void handleBuy() = 0;
	virtual double getIndex() const { return index_; }
	virtual bool hasCrashed() const { return has_crashed_; }

protected:
	FinancialMarket() : index_(1000), has_crashed_(false) {}

	virtual void crash();

	int index_;
	bool has_crashed_;

private:
	FinancialMarket(const FinancialMarket& rhs);			//non-copyable
	FinancialMarket& operator=(const FinancialMarket& rhs);	//non-copyable
};

class StockMarket : public FinancialMarket
{
public:
	virtual ~StockMarket(){}
	virtual void handleSell();
	virtual void handleBuy();
};

class BondMarket : public FinancialMarket
{
public:
	virtual ~BondMarket(){}
	virtual void handleSell();
	virtual void handleBuy();
};

class ForeignExchangeMarket : public FinancialMarket
{
public:
	virtual~ ForeignExchangeMarket(){}
	virtual void handleSell();
	virtual void handleBuy();
};

#endif
