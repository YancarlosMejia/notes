/*
 * File:   item.cpp
 * Author: Rossy, Lim
 *
 * Created on July 25, 2010
 */

#include "item.h"

#include <sstream>


Item::Item(int itemID, std::string label, int initialStock) :
    m_ItemID        (itemID),
    m_Label         (label)
{
    if (initialStock >= 0)
        m_ItemStock = initialStock;
    else
        m_ItemStock = 0;
}


void Item::modifyStock (int newStock)
{
    if (newStock >= 0)
        m_ItemStock = newStock;
}

std::string Item::getReport()
{
    std::string report = getLabel();
    report += " - ID# ";
    report += intToString( getItemID() );
    report += " - Stock: ";
    report += intToString( getStock() );
    report += "\n";

    return report;
}

std::string Item::intToString (int n)
{
   std::stringstream stream;
   stream << n;

   return stream.str();
}
