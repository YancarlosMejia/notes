/*
 * File:   inventory.cpp
 * Author: Rossy, Lim
 *
 * Created on July 25, 2010
 */

#include "inventory.h"


Inventory::~Inventory()
{
    Items::iterator i;
    for (i = m_Items.begin();
            i != m_Items.end();
            i++)
    {
        delete (*i);
    }
}


bool Inventory::addItem (int itemID, std::string label, int initialStock)
{
    //check if item is already in set
    if (findItem(itemID) != m_Items.end())
        return false;

    Item* newItem = new Item(itemID, label, initialStock);
    m_Items.insert(newItem);

    notifyObservers();

    return true;
}


bool Inventory::removeItem (int itemID)
{
    //verify item is already in set
    Items::iterator i = findItem(itemID);
    if (i == m_Items.end())
        return false;

    m_Items.erase(i);

    notifyObservers();

    return true;
}


std::string Inventory::getInventoryReport ()
{
    std::string report;

    for (Items::iterator i = m_Items.begin();
            i != m_Items.end();
            i++)
    {
        report += (*i)->getReport();
    }
    
    return report;
}


int Inventory::getItemStock (int itemID)
{
    //verify item is already in set
    Items::iterator i = findItem(itemID);
    if (i == m_Items.end())
        return -1;

    //return stock of item
    return (*i)->getStock();
}


std::string Inventory::getItemLabel (int itemID)
{
    //verify item is already in set
    Items::iterator i = findItem(itemID);
    if (i == m_Items.end())
        return "";

    //return label of item
    return (*i)->getLabel();
}


void Inventory::modifyItemStock (int itemID, int newStock)
{
    //verify item is already in set
    Items::iterator i = findItem(itemID);
    if (i == m_Items.end())
        return;

     //modify item's stock
    (*i)->modifyStock(newStock);

    notifyObservers();
}


Items::iterator Inventory::findItem (int itemID)
{
    if (m_Items.empty())
        return m_Items.end();

    Items::iterator i = m_Items.begin();
    
    while ((*i)->getItemID() != itemID)
    {
        i++;
        
        if (i == m_Items.end())            //Item is not in set
            break;
    }

    return i;                              //Item found, return iterator to it
}
