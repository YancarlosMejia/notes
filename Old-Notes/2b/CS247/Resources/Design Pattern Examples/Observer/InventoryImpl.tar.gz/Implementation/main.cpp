/* 
 * File:   main.cpp
 * Author: Rossy, Lim
 *
 * Created on July 25, 2010
 */


#include "inventory.h"
#include "inventoryobserver.h"


/*Program in current state will create an inventory and populate it with some
test items. As the inventory is modified, a 'report' will print to standard
output. */


int main(int argc, char** argv) {

    //create inventory
    Inventory inv;

    //create observer
    InventoryObserver invObs (&inv);

    //subscribe observer
    inv.subscribe(&invObs);

    //Add some test items
    inv.addItem(1, "Ball", 5);
    inv.addItem(2, "Shirt", 1);
    inv.addItem(3, "Phone");        //default argument = 0
    inv.modifyItemStock(3, 10);
    inv.modifyItemStock(1, 0);
    inv.removeItem(1);

    return (0);
}

