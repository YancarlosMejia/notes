/* 
 * File:   subject.h
 * Author: Rossy, Lim
 *
 * Created on July 25, 2010
 */

#ifndef _SUBJECT_H
#define	_SUBJECT_H

#include <set>

#include "observer.h"

typedef std::set<Observer*> Observers;

class Subject {

public:
    void subscribe (Observer*);                 //Add referenced observer to set of observers
    void unsubscribe (Observer*);               //Remove referenced observer to set of observers

protected:
    void notifyObservers();                     //Notify subscribed observers of update

private:
    Observers m_observers;                      //Set of subscribed observers

};


#endif	/* _SUBJECT_H */

