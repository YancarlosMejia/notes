/*
 * File:   inventoryobserver.cpp
 * Author: Rossy, Lim
 *
 * Created on July 25, 2010
 */


#include "inventoryobserver.h"

#include <string>
#include <ctime>
#include <iostream>


using namespace std;


void InventoryObserver::update (Subject* inventory)
{
    if (m_subject != NULL && inventory == m_subject)
    {
        //get updated inventory report
        string report = m_subject->getInventoryReport();

        cout << report;
        cout << endl << "----------------------" << endl;
    }

}