/* 
 * File:   inventoryobserver.h
 * Author: Rossy, Lim
 *
 * Created on July 25, 2010
 */

#ifndef _INVENTORYOBSERVER_H
#define	_INVENTORYOBSERVER_H

#include "observer.h"
#include "subject.h"
#include "inventory.h"


class InventoryObserver : public Observer {

public:
    InventoryObserver (Subject* subject) {m_subject = static_cast<Inventory*> (subject);}

    virtual void update (Subject*);     


private:

    Inventory* m_subject;               //subject for which this observer is made

    
};


#endif	/* _INVENTORYOBSERVER_H */

