/*
 * File:   subject.cpp
 * Author: Rossy, Lim
 *
 * Created on July 25, 2010
 */

#include "subject.h"


void Subject::subscribe(Observer* newObserver)
{
    m_observers.insert(newObserver);
}


void Subject::unsubscribe(Observer* oldObserver)
{
    m_observers.erase(oldObserver);
}


void Subject::notifyObservers()
{
    Observers::iterator i;

    for (i = m_observers.begin();
            i != m_observers.end();
            i++)
    {
        (*i)->update( this );
    }
    
}
