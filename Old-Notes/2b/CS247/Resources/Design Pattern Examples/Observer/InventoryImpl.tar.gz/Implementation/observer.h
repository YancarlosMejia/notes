/* 
 * File:   observer.h
 * Author: Rossy, Lim
 *
 * Created on July 25, 2010
 */

#ifndef _OBSERVER_H
#define	_OBSERVER_H

class Subject;

class Observer {

public:

    virtual void update (Subject*) = 0;

};


#endif	/* _OBSERVER_H */

