/* 
 * File:   inventory.h
 * Author: Rossy, Lim
 *
 * Created on July 25, 2010
 */

#ifndef _INVENTORYSUBJECT_H
#define	_INVENTORYSUBJECT_H

#include "item.h"
#include "subject.h"
#include <set>
#include <string>

typedef std::set<Item*> Items;


class Inventory : public Subject {

public:
    virtual ~Inventory();

    //Add item to inventory
    bool addItem (int itemID, std::string label, int initialStock = 0);

    //Remove item from inventory
    bool removeItem (int itemID);

    //Return string with info on all items in the inventory
    std::string getInventoryReport ();

    //Return current stock of specified item
    int getItemStock (int itemID);

    //Return label of specified item
    std::string getItemLabel (int itemID);

    //Modify current stock of specified item
    void modifyItemStock (int itemID, int newStock);

protected:
    //Returns iterator to specified item
    Items::iterator findItem (int itemID);

private:
    Items m_Items;                      //Set of items in inventory
    
};


#endif	/* _INVENTORYSUBJECT_H */

