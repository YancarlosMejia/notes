/* 
 * File:   item.h
 * Author: Rossy, Lim
 *
 * Created on July 25, 2010
 */

#ifndef _ITEM_H
#define	_ITEM_H

#include <string>


class Item {
public:
    Item (int itemID, std::string label, int initialStock = 0);

    int getItemID   ()      {return m_ItemID;}
    std::string getLabel () {return m_Label;}
    int getStock    ()      {return m_ItemStock;}

    std::string getReport();        //generate string with summary of info

    void modifyStock (int);

private:
    std::string intToString (int);      //helper function for getReport

    int m_ItemID;                    //Identification # for item
    std::string m_Label;             //Name of item

    int m_ItemStock;                 //# of items of this type in stock

};


#endif	/* _ITEM_H */

