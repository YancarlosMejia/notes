#include <iostream>
#include "fleetTracker.h"
#include "subject.h"
#include "vehicle.h"

using namespace std;

FleetTracker::FleetTracker(Vehicle &subject) 
{	
	_subject = &subject;
	_subject->subscribe(*this);
}

void FleetTracker::update()
{
	// If this was real, we would update the database of fleet tracking information on this specifc vehicle

	this->PrintStatus();

}

// for the purpose of this code, all each observer does is print out different data sets
void FleetTracker::PrintStatus()
{
	cout << endl;
	cout << "**FLEET TRACKER INFO UPDATE RECEIVED FROM VEHICLE**" << endl;

	// pull the properties of the vehicle
	cout << "Location of vehicle: : " << _subject->GetPosition() << endl;
	cout << "Current speed of vehicle : " << _subject->GetSpeed() << endl;
	cout << "Current fuel level : " << _subject->GetFuelLevel() << endl;
	cout << "Doors are locked : " << boolToText(_subject->IsLocked()) << endl << endl;
}