#ifndef _SUBJECT_H_
#define _SUBJECT_H_

#include <set>

class Observer;

class Subject 
{
public:
       void subscribe( Observer& );
       void unsubscribe( Observer& );
protected:
       void notify();
private:
       std::set<Observer*> _observers;        
}; 


#endif