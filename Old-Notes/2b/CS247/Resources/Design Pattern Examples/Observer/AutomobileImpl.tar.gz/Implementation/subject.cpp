#include <set>
#include "subject.h"
#include "observer.h"

void Subject::subscribe (Observer &newObs) 
{
    _observers.insert(&newObs);
}


void Subject::unsubscribe (Observer &formerView) 
{
     _observers.erase(&formerView);
}


void Subject::notify()
{
  std::set<Observer*>::iterator i;
  for (i = _observers.begin(); i != _observers.end(); ++i)
    (*i)->update();
}
