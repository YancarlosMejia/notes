
#include <iostream>
#include <string>
#include <cstdlib>
#include <stdio.h>
#include "dashBoard.h"
#include "fleetTracker.h"
#include "lowJack.h"
#include "onStar.h"
#include "vehicle.h"


using namespace std;

int main(int argc, char* argv[])
{	
	Vehicle *prius = new Vehicle(0.5); // economic?

	DashBoard *priusDash = new DashBoard(*prius);
	FleetTracker *priusTracker = new FleetTracker(*prius);
	LowJack *priusGotJacked = new LowJack(*prius);
	OnStar *WhyDoesMyPriusHaveOnStar = new OnStar(*prius);

	cout << "Welcome to the Observation pattern based simulation" << endl;
	cout << "The program following this will simulate the notify-update response designed by this code" << endl;

	cout << "Press Enter to start your Prius...";
	getchar();

	prius->TurnOnCar(); // its a prius, we can leave it on all the time ;)
	cout << "Press Enter to drive to work...";
	getchar();
	
	prius->DriveDistance(5); // drive to work
	cout << "Press Enter to go home from work...";
	getchar();

	prius->DriveDistance(-5, 100, true); // late night at work drive home
	cout << "Press Enter to go for a max speed run...";
	getchar();

	prius->DriveDistance(10, 150, true, true); // max speed run in the rain at night in your prius
	cout << "Press Enter to return home after max speed run";
	getchar();

	prius->DriveDistance(-10, 30, true, false, true); // drive home, stoped raining, at night, with the windows open
	cout << "Press Enter to end the simulation";
	getchar();

	//then you loose your prius becuase fleet tracker was watching. 

	 cout << "Simulation Complete" << endl;

	 getchar();

	return 0;
}

