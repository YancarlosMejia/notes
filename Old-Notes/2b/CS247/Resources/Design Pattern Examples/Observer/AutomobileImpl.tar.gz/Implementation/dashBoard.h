#ifndef _DASH_BOARD_H_
#define _DASH_BOARD_H_

#include <string>
#include <iostream>
#include "observer.h"
#include "vehicle.h"

class DashBoard : public Observer
{
public:
	DashBoard(Vehicle&);
	virtual void update();
private:
	void PrintStatus();
};


#endif