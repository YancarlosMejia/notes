#include "vehicle.h"
#include <math.h>
#include <stdlib.h>

using namespace std;


// Initialize the vehicle object
// Economy specifies how much fuel is concumed for one unit of distance
Vehicle::Vehicle(double economy)
{
	 m_speed = 0 ;
	 m_position = 0.0f;
	 m_locked =  false;
	 m_lights =  false;
	 m_fuelLevel =  1000;
	 m_windows =  false; // true if windows are down
	 m_wipers =  false; // true if wipers on 
	 m_engineTemp = 20; // in degress celcius room temp when car is off
	 m_odometer =  10000; // arbitrary  
	 m_vin =  1234567890; //10 digits 
	 m_isOn =  false; //car is off initially 
	 m_systemTime =  0;
	 m_economy = economy;
}

Vehicle::Vehicle()
{
	//default Constructor;
}

// Driving Methods (for test harness) in the actual application thse would be set by the sensors in the vehicle
void Vehicle::TurnOnCar()
{
	m_isOn = true;
	m_engineTemp = 170;	
	notify();	
}

void Vehicle::DriveDistance(int distance)
{
	m_isOn = true;
	m_engineTemp = 200;
	m_position += (double)distance;
	m_fuelLevel -= (distance * m_economy); // arbitrary constant
	m_odometer += abs(distance); // distance is a vector, odometers only go up, position can go up and down
	m_speed = 50; // arbitrary when not specified
	m_lights = false;
	m_wipers = false;
	m_windows = false;
	notify();
}

void Vehicle::DriveDistance(int distance, int speed)
{
	m_isOn = true;
	m_engineTemp = 200;
	m_position += (double)distance;
	m_fuelLevel -= (distance * m_economy); // arbitrary constant
	m_odometer += abs(distance); // distance is a vector, odometers only go up, position can go up and down
	m_speed = speed;
	m_lights = false;
	m_wipers = false;
	m_windows = false;
	notify();
}

void Vehicle::DriveDistance(int distance, int speed, bool atNight)
{
	m_isOn = true;
	m_engineTemp = 200;
	m_position += (double)distance;
	m_fuelLevel -= (distance * m_economy); // arbitrary constant
	m_odometer += abs(distance); // distance is a vector, odometers only go up, position can go up and down
	m_speed = speed;
	m_lights = atNight;
	m_wipers = false;
	m_windows = false;
	notify();
}

void Vehicle::DriveDistance(int distance, int speed, bool atNight, bool inRain)
{
	m_isOn = true;
	m_engineTemp = 200;
	m_position += (double)distance;
	m_fuelLevel -= (distance * m_economy); // arbitrary constant
	m_odometer += abs(distance); // distance is a vector, odometers only go up, position can go up and down
	m_speed = speed;
	m_lights = atNight;
	m_wipers = inRain;
	m_windows = false;
	notify();
}

void Vehicle::DriveDistance(int distance, int speed, bool atNight, bool inRain, bool windowsOpen)
{
	m_isOn = true;
	m_engineTemp = 200;
	m_position += (double)distance;
	m_fuelLevel -= (distance * m_economy); // arbitrary constant
	m_odometer += abs(distance); // distance is a vector, odometers only go up, position can go up and down
	m_speed = speed;
	m_lights = atNight;
	m_wipers = inRain;
	m_windows = windowsOpen;
	notify();
}

void Vehicle::openTrunk()
{
	// do nothing, real case, this would open the trunk
}

// Public Properties (accessors)
int Vehicle::GetSpeed()
{
	return m_speed;
}

double Vehicle:: GetPosition()
{
	return m_position;
}

bool Vehicle:: IsLocked()
{
	return m_locked;
}

void Vehicle:: SetLocked(bool locked)
{
	m_locked = locked;
}

bool Vehicle:: LightsOn()
{
	return m_lights;
}

void Vehicle:: SetLights(bool on)
{
	m_lights = on;
}

bool Vehicle:: WindowsOpen()
{
	return m_windows;
}

void Vehicle:: SetWindows(bool down)
{
	m_windows = down;
}

bool Vehicle:: WipersOn()
{
	return m_wipers;
}

void Vehicle::SetWipers(bool on)
{
	m_wipers = on;
} 

void Vehicle:: OpenTrunk()
{
	openTrunk();
} 

int Vehicle::GetFuelLevel()
{
	return m_fuelLevel;
} 

int Vehicle::EngineTemp()
{
	return m_engineTemp;
} 

long Vehicle:: Odometer()
{
	return m_odometer;
} 

long Vehicle:: GetVIN()
{
	return m_vin;
} 

int Vehicle::GetSystemTime()
{
	return m_systemTime;
}