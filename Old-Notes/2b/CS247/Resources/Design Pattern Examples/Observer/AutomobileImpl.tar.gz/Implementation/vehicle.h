#ifndef _VEHICLE_H_
#define _VEHICLE_H_

#include <string>
#include <iostream>
#include "subject.h"

class Vehicle : public Subject
{
public:
	Vehicle();
	Vehicle(double);
	int GetSpeed();
	double GetPosition(); // kms 
	bool IsLocked();
	void SetLocked(bool); 
	bool LightsOn(); 
	void SetLights(bool); 
	bool WindowsOpen(); 
	void SetWindows(bool); 
	bool WipersOn(); 
	void SetWipers(bool); 
	void OpenTrunk(); 
	int GetFuelLevel(); 
	int EngineTemp(); 
	long Odometer(); 
	long GetVIN(); 
	int GetSystemTime();

	void TurnOnCar();
	void DriveDistance(int); // distance to drive
	void DriveDistance(int,int); // distance, speed
	void DriveDistance(int,int, bool); // distance, speed, at night
	void DriveDistance(int, int, bool, bool); //distance, speed, at night, in the rain
	void DriveDistance(int, int, bool, bool, bool); // distance, speed, at night, in the rain, windows open
	// etc.. test all properties, covering everything isnt relevant to this assignment

private:
	void openTrunk();

	int m_speed;
	double m_position;
	bool m_locked;
	bool m_lights;
	int m_fuelLevel;
	bool m_windows; 
	bool m_wipers; 
	int m_engineTemp; 
	long m_odometer; 
	long m_vin; 
	bool m_isOn; 
	int m_systemTime; // would use a time object here, but for demonstration sake..
	double  m_economy; // fuel points/km
}; 



#endif