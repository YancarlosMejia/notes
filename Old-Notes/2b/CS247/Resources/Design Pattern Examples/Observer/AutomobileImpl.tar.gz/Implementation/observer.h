#ifndef _OBSERVER_H_
#define _OBSERVER_H_

#include "vehicle.h"

class Observer  
{
public:
	 Observer();     
	 virtual ~Observer();
	 virtual void update() = 0;
protected:
	Vehicle *_subject;
	std::string boolToText(bool);
};

#endif