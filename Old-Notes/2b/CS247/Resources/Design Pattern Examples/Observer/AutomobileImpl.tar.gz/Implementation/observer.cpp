#include <iostream>
#include "observer.h"
#include "vehicle.h"

Observer::Observer() {}

Observer::~Observer() {}

std::string Observer::boolToText(bool input)
{
	if(input)
		return "True";
	else
		return "False";
}
