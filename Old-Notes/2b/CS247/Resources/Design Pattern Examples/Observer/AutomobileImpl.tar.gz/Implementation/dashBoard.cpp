#include <iostream>
#include "dashBoard.h"
#include "subject.h"
#include "vehicle.h"

using namespace std;

DashBoard::DashBoard(Vehicle &subject) 
{	
	_subject = &subject;
	_subject->subscribe(*this);
}

void DashBoard::update()
{	
	// in this case, we just display the info that DashBoard would need from the car
	this->PrintStatus();

}

// for the purpose of this code, all each observer does is print out different data sets
void DashBoard::PrintStatus()
{
	cout << endl;
	cout << "**DASHBOARD DISPLAY**" << endl;

	// pull the properties of the vehicle	
	cout << "Current speed of vehicle : " << _subject->GetSpeed() << endl;		
	cout << "Lights are on : " << boolToText(_subject->LightsOn()) << endl;
	cout << "Engine Temperature : " << _subject->EngineTemp() << endl;
	cout << "Odometer : " << _subject->Odometer() << endl;
	cout << "Fuel Level : " << _subject->GetFuelLevel() << endl;
	cout << "Time : " << _subject->GetSystemTime() << endl;
}
