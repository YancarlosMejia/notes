#include <iostream>
#include "onStar.h"
#include "subject.h"
#include "vehicle.h"

using namespace std;

OnStar::OnStar(Vehicle &subject) 
{	
	_subject = &subject;
	_subject->subscribe(*this);
}

void OnStar::update()
{
	// If this was real, we would update the database of onstar information on this specifc vehicle	
	this->PrintStatus();

}

// for the purpose of this code, all each observer does is print out different data sets
void OnStar::PrintStatus()
{
	cout << endl;
	cout << "**ON STAR INFO UPDATE RECEIVED FROM VEHICLE**" << endl;

	// pull the properties of the vehicle
	cout << "Location of vehicle: : " << _subject->GetPosition() << endl;
	cout << "Current speed of vehicle : " << _subject->GetSpeed() << endl;	
	cout << "Doors are locked : " << boolToText(_subject->IsLocked()) << endl;
	cout << "Lights are on : " << boolToText(_subject->LightsOn()) << endl;
	cout << "Engine Temperature : " << _subject->EngineTemp() << endl;
	cout << "Windows are Open : " << boolToText(_subject->WindowsOpen()) << endl;
	cout << "Vehicle VIN : " << _subject->GetVIN() << endl << endl;
}

// In the case of onstar, we would provide methods to 
//call into the subject and unlock the doors, turn off the lights etc etc