#ifndef _FLEET_TRACKER_H_
#define _FLEET_TRACKER_H_

#include <string>
#include <iostream>
#include "observer.h"
#include "vehicle.h"

class FleetTracker : public Observer
{
public:
	FleetTracker(Vehicle&);
	virtual void update();
private:
	void PrintStatus();	
};

#endif