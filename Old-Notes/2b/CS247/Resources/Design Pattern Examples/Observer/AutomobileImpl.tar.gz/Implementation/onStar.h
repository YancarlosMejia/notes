#ifndef _ON_STAR_H_
#define _ON_STAR_H_

#include <string>
#include <iostream>
#include "observer.h"
#include "vehicle.h"

class OnStar : public Observer
{
public:
	OnStar(Vehicle&);
	virtual void update();
private:
	void PrintStatus();	
};

#endif