#ifndef _LOW_JACK_H_
#define _LOW_JACK_H_

#include <string>
#include <iostream>
#include "observer.h"
#include "vehicle.h"

class LowJack : public Observer
{
public:
	LowJack(Vehicle&);	
	virtual void update();
private:
	void PrintStatus();	
};

#endif