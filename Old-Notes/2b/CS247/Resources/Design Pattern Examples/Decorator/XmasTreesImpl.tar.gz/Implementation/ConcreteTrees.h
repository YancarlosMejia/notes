/*
 *  ConcreteTrees.h
 *      This file contains declarations of concrete subclasses of the abstract 
 *      Tree class. These classes represent the actual plants.
 *  Created by Brian Attwell on 7/24/10.
 *
 */

#ifndef CONCRETE_TREE__
#define CONCRETE_TREE__

#include "Tree.h"
#include <string>

class Evergreen : public Tree {
public:
    virtual unsigned int cost() const;
    virtual std::string description() const;
    
} ;

class FakeEvergreen : public Tree {
public:
    virtual unsigned int cost() const;
    virtual std::string description() const;
    
} ;

class Palm : public Tree {
public:
    virtual unsigned int cost() const;
    virtual std::string description() const;
    
} ;

#endif // CONCRETE_TREE__