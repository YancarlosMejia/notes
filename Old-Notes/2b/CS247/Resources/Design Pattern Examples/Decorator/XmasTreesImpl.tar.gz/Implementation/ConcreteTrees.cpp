/*
 *  ConcreteTrees.cpp
 *
 *  Created by Brian Attwell on 7/24/10.
 *
 */

#include "ConcreteTrees.h"

using namespace std;

unsigned int Evergreen::cost() const {
    return 50;
}

string Evergreen::description() const {
    return "Evergreen tree";
}

unsigned int FakeEvergreen::cost() const {
    return 25;
}

string FakeEvergreen::description() const {
    return "'Fake' Evergreen tree";
}

unsigned int Palm::cost() const {
    return 120;
}

string Palm::description() const {
    return "Palm tree";
}