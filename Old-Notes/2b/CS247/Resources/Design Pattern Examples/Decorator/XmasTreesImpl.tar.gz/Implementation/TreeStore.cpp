/*
 *  TreeStore.cpp
 *
 *  Created by Brian Attwell on 7/26/10.
 *
 */

#include "TreeDecorators.h"
#include "ConcreteTrees.h"
#include "TreeStore.h"
#include <iostream>
#include <algorithm>

using namespace std;

TreeStore::TreeStore() {
    
    Tree* newestTree = NULL;
    
    newestTree = new FakeEvergreen();       
    treeComponents_.push_back(newestTree);
    trees_.push_back(newestTree);
    
    newestTree = new Evergreen();
    treeComponents_.push_back(newestTree);
    trees_.push_back(newestTree);
    
    newestTree = new Palm();
    treeComponents_.push_back(newestTree);    
    trees_.push_back(newestTree);
    
    newestTree = new Palm();
    treeComponents_.push_back(newestTree);    
    newestTree = new Tinsel(newestTree);
    treeComponents_.push_back(newestTree);    
    newestTree = new Baubles(newestTree);
    treeComponents_.push_back(newestTree);    
    trees_.push_back(newestTree);
    
    newestTree = new FakeEvergreen();
    treeComponents_.push_back(newestTree);    
    newestTree = new Tinsel(newestTree);
    treeComponents_.push_back(newestTree);    
    newestTree = new Tinsel(newestTree);
    treeComponents_.push_back(newestTree);    
    newestTree = new Baubles(newestTree);
    treeComponents_.push_back(newestTree);    
    newestTree = new Frost(newestTree);
    treeComponents_.push_back(newestTree);    
    trees_.push_back(newestTree);
    
    newestTree = new FakeEvergreen();
    treeComponents_.push_back(newestTree);    
    newestTree = new Tinsel(newestTree);
    treeComponents_.push_back(newestTree);    
    newestTree = new Baubles(newestTree);
    treeComponents_.push_back(newestTree);    
    newestTree = new Baubles(newestTree);
    treeComponents_.push_back(newestTree);    
    newestTree = new Frost(newestTree);
    treeComponents_.push_back(newestTree);    
    trees_.push_back(newestTree);
    
    newestTree = new Evergreen();
    treeComponents_.push_back(newestTree);    
    newestTree = new Baubles(newestTree);
    treeComponents_.push_back(newestTree);    
    trees_.push_back(newestTree);
    
    newestTree = new Evergreen();
    treeComponents_.push_back(newestTree);    
    newestTree = new Baubles(newestTree);
    treeComponents_.push_back(newestTree);    
    newestTree = new Frost(newestTree);
    treeComponents_.push_back(newestTree);    
    trees_.push_back(newestTree);
    
}

void TreeStore::displayMenu() const {
    
    cout << "We have an EXCELLENT selection this year!\n";
    for (unsigned int i = 0; i < trees_.size(); i++) {
        cout << (i+1) << ") " << trees_[i]->description() 
             << " for only $" <<  trees_[i]->cost() << "." << endl;;
    }
    
    const int FIRST_TREE_INDEX = 1;
    cout << "Select from our AMAZING menu using a NUMBER in the range [" 
         << FIRST_TREE_INDEX << "," << trees_.size() << "]" << endl;
    
}

void TreeStore::buyTree(unsigned int selection) const {
    
    const unsigned int FIRST_TREE_INDEX = 1;
    if (selection < FIRST_TREE_INDEX || selection > trees_.size()) {
        cout << "Sorry, we can't sell trees that we don't own." << endl;
        return;
    }
    
    const Tree& t = *(trees_[selection-1]);
    cout << "For $" << t.cost() <<  " you bought a \"" << t.description() 
         << "\"" << endl;
    cout << "Good choice! Don't worry, there are "
         "plenty more where that came from!" << endl;
    
}

static void deleteTreeComponent(const Tree* t) {
    delete t;
}

TreeStore::~TreeStore() {
    for_each(treeComponents_.begin(), treeComponents_.end(), deleteTreeComponent);
}