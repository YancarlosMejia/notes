/*
 *  main.cpp
 *
 *  Created by Brian Attwell on 7/24/10.
 *
 */

#include "TreeStore.h"
#include <iostream>
#include <string>
#include <cstdlib>

using namespace std;

int main (int argc, char * const argv[]) {

    cout << "Welcome to the \"TreeStore\" example program!\n";

    TreeStore store;
    while (true) {
        
        cout << "OPTIONS" << endl
            << "\t1: Inspect the menu" << endl
            << "\t2: Buy a tree" << endl
            << "\t3: Leave, and give Brian Attwell 120%" << endl
            << "Please select an option" << endl;
        
        string input;
        cin >> input;
        int choice = atoi(input.c_str());
        
        switch (choice) {
            case 1:
                cout << endl;
                store.displayMenu();
                break;
            case 2: {
                cout << "Please enter the tree that you want:";
                string input2;
                cin >> input2;
                int selection = atoi(input2.c_str());
                cout << endl;
                store.buyTree(selection);
            } break;
            case 3:
                cout << "Have a good day!!!" << endl;
                return 0;
            default:
                cout << "(oops, that wasn't an option)" << endl;
                break;

        } // switch
        
        cout << endl << endl;
        
    } // while(true)
    
} // int main
