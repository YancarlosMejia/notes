/*
 *  Tree.h
 *      Abstract class declaration for a tree used in retail.
 *
 *  Created by Brian Attwell on 7/24/10.
 *
 */

#ifndef TREE__
#define TREE__

#include <string>

class Tree {
public:
    virtual ~Tree() {}
    virtual unsigned int cost() const = 0;
    virtual std::string description() const = 0;
};

#endif // TREE__