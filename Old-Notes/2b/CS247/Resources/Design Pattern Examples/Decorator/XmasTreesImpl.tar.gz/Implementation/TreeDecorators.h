/*
 *  TreeDecorators.h
 *      This file contains the TreeDecorator abstract class declaration as
 *      well as three concrete subclasses of it.
 *
 *  Created by Brian Attwell on 7/24/10.
 */

#ifndef TREE_DECORATORS__
#define TREE_DECORATORS__

#include "Tree.h"

class TreeDecorator : public Tree {
    const Tree* component_;
protected:
    TreeDecorator(const Tree*);
    const Tree* treeComponent() const;
};

class Tinsel : public TreeDecorator {
    static const int COST_OF_TINSEL = 40;
public:
    Tinsel(const Tree*);
    virtual unsigned int cost() const;
    virtual std::string description() const;
};

class Baubles : public TreeDecorator {
    static const int COST_OF_BAUBLES = 20;
public:
    Baubles(const Tree*);
    virtual unsigned int cost() const;
    virtual std::string description() const;
};

class Frost : public TreeDecorator {
   static const int COST_OF_FROST = 5;
public:
    Frost(const Tree*);
    virtual unsigned int cost() const;
    virtual std::string description() const;
};


#endif // TREE_DECORATORS__