/*
 *  TreeDecorators.cpp
 *
 *  Created by Brian Attwell on 7/24/10.
 *
 */

#include "TreeDecorators.h"

TreeDecorator::TreeDecorator(const Tree* t) : component_(t) {}

const Tree* TreeDecorator::treeComponent() const {
    return component_;
}

unsigned int Tinsel::cost() const {
    return COST_OF_TINSEL + treeComponent()->cost();
}

Tinsel::Tinsel(const Tree* t) : TreeDecorator(t) {}

std::string Tinsel::description() const {
    return treeComponent()->description() + ", tinselled";
}

unsigned int Baubles::cost() const {
    return COST_OF_BAUBLES + treeComponent()->cost();
}

Baubles::Baubles(const Tree* t) : TreeDecorator(t) {}

std::string Baubles::description() const {
    return treeComponent()->description() + ", baubled";
}

unsigned int Frost::cost() const {
    return COST_OF_FROST + treeComponent()->cost();
}

Frost::Frost(const Tree* t) : TreeDecorator(t) {}

std::string Frost::description() const {
    return treeComponent()->description() + ", frosted";
}
