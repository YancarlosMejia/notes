/*
 *  TreeStore.h
 *      The declaration for a concrete tree store class.
 *
 *  Created by Brian Attwell on 7/26/10.
 *
 */

#include "Tree.h"
#include <vector>

class TreeStore {
    std::vector<const Tree*> trees_;
    std::vector<const Tree*> treeComponents_;
public:
    TreeStore();
    ~TreeStore();
    
    void displayMenu() const;
    void buyTree(unsigned int selection) const;
};

