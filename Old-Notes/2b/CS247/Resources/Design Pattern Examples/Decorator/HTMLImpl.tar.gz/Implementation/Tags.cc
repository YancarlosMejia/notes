#include "Tags.h"

BoldTag::BoldTag(HTMLExpr* expr) : HTMLTag(expr) {
}

std::string BoldTag::str() {
    return "<b>" + HTMLTag::str() + "</b>";
}


UnderlineTag::UnderlineTag(HTMLExpr* expr) : HTMLTag(expr) {}

std::string UnderlineTag::str() {
    return "<ul>" + HTMLTag::str() + "</ul>";
}


ItalicTag::ItalicTag(HTMLExpr* expr) : HTMLTag(expr) {}

std::string ItalicTag::str() {
    return "<i>" + HTMLTag::str() + "</i>";
}


LinkTag::LinkTag(HTMLExpr* expr, std::string link) : HTMLTag(expr), link_(link) {}

std::string LinkTag::str() {
    return "<a href='" + link_ + "'>" + HTMLTag::str() + "</a>";
}


SpanTag::SpanTag(HTMLExpr* expr, std::string style) : HTMLTag(expr), style_(style) {}

std::string SpanTag::str() {
    return "<span style='" + style_ + "'>" + HTMLTag::str() + "</span>";
}
