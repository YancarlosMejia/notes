#ifndef TEXT_H
#define TEXT_H

#include "HTML.h"

class Text : public HTMLExpr {
    public:
        Text(std::string text);
        std::string str();
    private:
        std::string text_;
};

#endif
