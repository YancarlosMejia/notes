#include "Text.h"
#include "Tags.h"
#include "HTML.h"
#include <iostream>

using namespace std;

int main() {
    HTMLExpr* text = new Text(std::string("This is my base text"));
    HTMLExpr* bold = new BoldTag(new ItalicTag(new UnderlineTag(new BoldTag(text))));
    HTMLExpr* link = new LinkTag(new SpanTag(bold, "margin-left: 30px;"), "http://www.facebook.com");
    cout << link->str() << endl;
    delete link;
    return 0;
}
