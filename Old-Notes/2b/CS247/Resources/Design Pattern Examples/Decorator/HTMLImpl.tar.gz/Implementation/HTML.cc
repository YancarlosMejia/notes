#include "HTML.h"

HTMLExpr::~HTMLExpr() {
}

HTMLTag::HTMLTag(HTMLExpr* expr) : expr_(expr) {
}

HTMLTag::~HTMLTag() {
    delete expr_;
}

std::string HTMLTag::str() {
    return expr_->str();
}
