#include "Text.h"

Text::Text(std::string text) : text_(text) {}

std::string Text::str() {
    return text_;
}
