#ifndef TAGS_H
#define TAGS_H

#include "HTML.h"

class BoldTag : public HTMLTag {
    public:
        BoldTag(HTMLExpr* expr);
        std::string str();
};

class UnderlineTag : public HTMLTag {
    public:
        UnderlineTag(HTMLExpr* expr);
        std::string str();
};

class ItalicTag : public HTMLTag {
    public:
        ItalicTag(HTMLExpr* expr);
        std::string str();
};

class LinkTag : public HTMLTag {
    public:
        LinkTag(HTMLExpr* expr, std::string link);
        std::string str();
    private:
        std::string link_;
};


class SpanTag : public HTMLTag {
    public:
        SpanTag(HTMLExpr* expr, std::string style);
        std::string str();
    private:
        std::string style_;
};



#endif
