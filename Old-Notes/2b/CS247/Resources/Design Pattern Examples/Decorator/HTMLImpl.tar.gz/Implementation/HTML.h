#ifndef HTML_H
#define HTML_H

#include <string>

class HTMLExpr {
    public:
        virtual ~HTMLExpr();
        virtual std::string str() = 0;
};

class HTMLTag : public HTMLExpr {
    public:
        std::string str();
    protected:
        HTMLTag(HTMLExpr* expr);
        ~HTMLTag();
    private:
        HTMLExpr* expr_;
};

#endif
