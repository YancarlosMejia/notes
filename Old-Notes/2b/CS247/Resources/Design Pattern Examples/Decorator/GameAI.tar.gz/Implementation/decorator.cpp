#include "decorator.h"
#include <string>
#include <iostream>

using namespace std;

// constructor
yellDecorator::yellDecorator(AI * a) : actionDecorator(a) {}

// adds a shout behaviour
void yellDecorator::action() {
	actionDecorator::action();
	cout<<actionDecorator::getName()<<" shouts out discouraging remarks."<<endl;
}

// constructor
shootDecorator::shootDecorator(AI * a) : actionDecorator(a) {}

// adds a gun shooting behaviour
void shootDecorator::action() {
	actionDecorator::action();
	cout<<actionDecorator::getName()<<" shoots its gun in random directions."<<endl;
}

// constructor
dodgeDecorator::dodgeDecorator(AI* a) : actionDecorator(a) {}

// adds a dodge behaviour
void dodgeDecorator::action() {
	actionDecorator::action();
	cout<<actionDecorator::getName()<<" dodges everything."<<endl;
}

