#include "baseAI.h"
#include <iostream>

using namespace std;

// constructor: sets ai name
baseAI::baseAI(string aiName) {
	name=aiName;
}

// returns the name of the AI
string baseAI::getName() {
	return name;
}

// defines the action of the base AI
void baseAI::action() {
	cout<<getName()<<" wanders aimlessly across the map."<<endl;
}
