#ifndef AI_H_
#define AI_H_

#include <string>

class AI {
	public:
		virtual std::string getName()=0;	// for getting the name of the AI
		virtual void action()=0;		// defines the actions taken by the AI
};

#endif
