#ifndef ACTIONDECORATOR_H_
#define ACTIONDECORATOR_H_

#include "ai.h"
#include <string>

class actionDecorator : public AI {
	public:
		void action();				// performs the AI action
		std::string getName();				// returns the AI name
	protected:
		actionDecorator(AI*);			// gets a view of the AI
	private:
		AI *_ai;
};

#endif
