#include "actionDecorator.h"
using namespace std;

// constructor
actionDecorator::actionDecorator(AI *a) : _ai(a) {}

// returns the AI name
string actionDecorator::getName() {
	return _ai->getName();
}

// performs the ai action
void actionDecorator::action() {
	_ai->action();
}
