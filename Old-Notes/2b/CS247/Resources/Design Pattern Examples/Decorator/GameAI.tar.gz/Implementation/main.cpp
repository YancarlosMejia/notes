#include "baseAI.h"
#include "decorator.h"
#include <iostream>

using namespace std;

int main() {

	// demonstrates decorator class wrapping around and enhancing the baseAI
	AI* type1 = new baseAI("Weak Enemy");
	AI* type2 = new yellDecorator(new baseAI("Medium Enemy"));
	AI* type3 = new shootDecorator(new yellDecorator(new baseAI("Hard Enemy")));
	AI* type4 = new dodgeDecorator(new shootDecorator(new yellDecorator(new baseAI("Ultimate Enemy"))));
	AI* type5 = new yellDecorator(new dodgeDecorator(new baseAI("Invincible But Otherwise Useless Enemy")));

	type1->action();
	cout<<endl;
	type2->action();
	cout<<endl;
	type3->action();
	cout<<endl;
	type4->action();
	cout<<endl;
	type5->action();
	cout<<endl;

	// demonstrating run-time upgrade of baseAI
	type1 = new shootDecorator(type1);
	type1->action();

	delete type1;
	delete type2;
	delete type3;
	delete type4;
	delete type5;

	return 0;
}
