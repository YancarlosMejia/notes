#ifndef BASEAI_H_
#define BASEAI_H_

#include "ai.h"
#include <string>

class baseAI : public AI {
	public:
		baseAI(std::string);		// constructor
		void action();			// performs the base AI action
		std::string getName();		// returns the AI name
	private:
		std::string name;
};

#endif
