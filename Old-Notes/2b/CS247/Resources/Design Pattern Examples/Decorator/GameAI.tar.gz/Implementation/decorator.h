#ifndef DECORATOR_H_
#define DECORATOR_H_

#include "actionDecorator.h"

class yellDecorator : public actionDecorator {
	public:
		yellDecorator(AI* a);
		void action();				// adds a shout to the AI behaviour

};

class shootDecorator : public actionDecorator {
	public:
		shootDecorator(AI* a);
		void action();				// adds a gun shooting AI behaviour
};

class dodgeDecorator : public actionDecorator {
	public:
		dodgeDecorator(AI* a);
		void action();				// adds a dodge behaviour to AI
};

#endif
