#include "DecoratorBase.h"

using std::string;

DecoratorBase::DecoratorBase(UserBase& aDec) : iBase(&aDec) {}
 
// Pass along all calls to the base

void DecoratorBase::DrawWebpage() const {
    iBase->DrawWebpage();
}


string DecoratorBase::GetName() const {
    return iBase->GetName();
}

