#ifndef ADS_DECORATOR_H
#define ADS_DECORATOR_H

#include "DecoratorBase.h"

class AdsDecorator : public DecoratorBase {
    public:
        AdsDecorator(UserBase& aDec);
	virtual ~AdsDecorator() {}
        virtual void DrawWebpage() const;

    private:
};

#endif


