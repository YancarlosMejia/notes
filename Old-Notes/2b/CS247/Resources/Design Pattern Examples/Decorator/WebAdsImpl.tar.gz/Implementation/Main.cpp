#include <iostream>

#include "Website.h"
#include "UserBase.h"

using std::cout;
using std::endl;

int main() {
    Website w;

    // Add user
    w.AddUser("Me");

    // Get Temporary access to a user
    UserBase& m = w.GetUser(0);
    m.DrawWebpage();
    cout << endl;
    
    // Subscribe the user
    w.Subscribe(m);

    // Get access to the user and re-draw the webpage
    UserBase& n(w.GetUser(0));
    n.DrawWebpage();
    cout << endl;
    
    // Unsubscribe the user
    w.Unsubscribe(m);

    // Get access to the user and re-draw the page
    UserBase& t(w.GetUser(0));
    t.DrawWebpage();
}

