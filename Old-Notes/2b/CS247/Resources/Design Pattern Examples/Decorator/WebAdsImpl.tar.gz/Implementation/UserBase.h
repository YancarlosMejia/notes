#ifndef USER_BASE_H
#define USER_BASE_H

#include <string>

// Declare the abstract class for
// users and all user decorators

class UserBase {
    public:
		virtual ~UserBase() {}
        virtual void  DrawWebpage() const = 0;
        virtual std::string GetName() const = 0;
};

#endif

