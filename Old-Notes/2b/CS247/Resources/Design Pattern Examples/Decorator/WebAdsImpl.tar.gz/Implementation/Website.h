#ifndef WEBSITE_H
#define WEBSITE_H

#include <string>
#include <vector>

#include "UserBase.h"

class Website {
    public:
        virtual ~Website();

        void AddUser(std::string aName);
        UserBase& GetUser(int aId) const;
        int NumUsers() const;
        void RemoveUser (UserBase& aUser);
        void Subscribe  (UserBase& aUser);
        void Unsubscribe(UserBase& aUser);

    private:
        std::vector<UserBase*> iUsers;
};

#endif

