#include <iostream>

#include "User.h"

using std::cout;
using std::endl;
using std::string;

User::User(std::string aName) : iName(aName) {}

// Draw the users webpage
void User::DrawWebpage() const {
    cout << "Welcome, " << iName << endl;
}


// Return the users name
string User::GetName() const {
    return iName;
}

