#ifndef DECORATOR_BASE_H
#define DECORATOR_BASE_H

#include <string>
#include "UserBase.h"

// Declare the base for all decorators
// Base contains a pointer to a UserBase
// which it re-directs all calls to

class DecoratorBase : public UserBase {
    public:
        DecoratorBase(UserBase& aDec);
		virtual ~DecoratorBase() {}
        
        virtual void DrawWebpage() const;
        virtual std::string GetName() const;

    private:
        UserBase* iBase;
};

#endif

