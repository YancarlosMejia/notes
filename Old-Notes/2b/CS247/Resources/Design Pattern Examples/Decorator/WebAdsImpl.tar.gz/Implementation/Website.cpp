#include "Website.h"
#include "User.h"
#include "AdsDecorator.h"

#include <iostream>
using std::cout;

using std::string;
using std::vector;

// Takes care of memory
Website::~Website() {
    for(unsigned int i = 0; i < iUsers.size(); i++) {
        delete iUsers[i];
    }
}

// Creates a new user with ads
void Website::AddUser(string aName) {
    UserBase* temp = new AdsDecorator(*(new User(aName)));
    iUsers.push_back(temp);
}

// Returns a user based on the vector index
UserBase& Website::GetUser(int aId) const {
    // Assumes aId is in range
    return *(iUsers[aId]);
}

// Returns the total number of users
int Website::NumUsers() const {
    return iUsers.size();
}

// Removes a user from the list
void Website::RemoveUser(UserBase& aUser) {
    for(unsigned int i = 0; i < iUsers.size(); i++) {
        if(iUsers[i] == &(aUser)) {
            delete iUsers[i];
            iUsers.erase(iUsers.begin() + i);
        }
    }
}

// Remove the ads from the user's view of the website
void Website::Subscribe(UserBase& aUser) {
        for(unsigned int i = 0; i < iUsers.size(); i++) {
            if( iUsers[i]->GetName() == aUser.GetName() ) {
                string name = aUser.GetName();
                delete iUsers[i];
                iUsers[i] = new User(name);
            }
        }
}

// Put the ads back into the user's view of the website
void Website::Unsubscribe(UserBase& aUser) {
        for(unsigned int i = 0; i < iUsers.size(); i++) {
            if( iUsers[i]->GetName() == aUser.GetName() ) {
                string name = aUser.GetName();
				delete iUsers[i];
                iUsers[i] = new AdsDecorator( *( new User( name ) ) );
            }
        }
}

