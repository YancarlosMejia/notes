#ifndef USER_H
#define USER_H

#include <string>
#include "UserBase.h"

class User : public UserBase {
    public:
        User(std::string aName);
        
        void DrawWebpage() const;
        std::string GetName() const;

    private:
        std::string iName;
};

#endif

