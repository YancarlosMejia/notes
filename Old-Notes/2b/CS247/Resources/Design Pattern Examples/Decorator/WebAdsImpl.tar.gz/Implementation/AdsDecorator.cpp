#include <iostream>

#include "AdsDecorator.h"

using std::cout;

AdsDecorator::AdsDecorator(UserBase& aDec) : DecoratorBase(aDec) {}

// Draw the ads, then draw the rest of the page
void AdsDecorator::DrawWebpage() const {
    cout << "BUY OUR PRODUCTS!!!!\n";
    DecoratorBase::DrawWebpage();
}

